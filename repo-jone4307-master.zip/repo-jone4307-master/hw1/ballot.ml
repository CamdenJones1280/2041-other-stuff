(* free code: don't worry, you aren't meant to understand this function yet. *)
let get_ballot_lines bfile = 
  let ic = open_in bfile in
  let rec get_bl acc = 
    match (try Some (input_line ic) with End_of_file -> None) with
    None -> List.rev acc
    | Some l -> get_bl (l::acc) in
  let ballot_lines = get_bl [] in
  let () = close_in ic in ballot_lines



(* Given a list of comma-delimited "ballots" return a list of lists where each
   element is the list of comma-delimited options.  
 *)
let rec ballots_from_lines (blines : string list) : string list list = 
match blines with 
| [] -> []
| h::t -> if h <> ";" then if h = "" then []::ballots_from_lines t else
  (String.split_on_char ',' h)::ballots_from_lines t else ballots_from_lines t



(* Identify the index of the first ballot that has a candidate not in the candidate list *)
(* Return None if all ballots are legal. *)

(* helper function for first error *)
let rec find_error ls1 ls2 =
match ls2 with 
| [] -> false
| h::t -> if List.mem h ls1 then true else find_error ls1 t

let rec first_error (cs : 'a list) (ballots : 'a list list) : int option = 
  let rec first_error_helper cs ballots acc =
  match ballots with
  | [] -> None
  | h::t -> if find_error cs h then first_error_helper cs t (acc+1) else if h<>[] then Some (acc +1) else first_error_helper cs t (acc+1)
  in first_error_helper cs ballots 0



(* Given a list of (candidate,score) pairs, compute the String length of the longest candidate *)
let rec max_len (sl : (string * float) list) = 
  let rec max_len_helper sl max =
  match sl with
  |[]-> max
  |(k,v)::t -> if String.length k <= max then max_len_helper t max else max_len_helper t (String.length k) 
  in max_len_helper sl 0



(* Pad the string s (with spaces) to length at least l *)
let rec pad (l : int) s = 
if String.length s < l then pad (l-1) s ^" " else s



(* free code: prints the list of rankings out *)
let print_rankings sl = 
  let padlen = max (String.length "Candidate") (max_len sl) in
  let () = print_endline ((pad padlen "Candidate") ^ " \t Score") in
  let () = print_endline ((String.make padlen '-') ^ " \t -----") in
  let rec p_loop = function [] -> () 
  | (c,s)::t -> let () = print_endline ((pad padlen c) ^ " \t " ^ (string_of_float s)) in p_loop t
in p_loop sl
