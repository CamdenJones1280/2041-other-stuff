(* a data type representing expressions.  Fill in: *)



(* defines type for each command we wish to use later on which for most is a formula*formula type
with 3 types thats are either place holding(rank and aggr) and make float that is converting formuala to a float *)
type formula = ConstExpr of float | DivExpr of formula * formula | AddExpr of formula * formula 
| SubExpr of formula * formula | MultExpr of formula * formula | MaxExpr of formula * formula
| MinExpr of formula * formula | VarRank of float | VarAggr of float



(*ties commands to their types and operations, rank and aggr are asigned to some number of type formula*)
let make_add f1 f2 = AddExpr(f1,f2)
let make_sub f1 f2 = SubExpr(f1,f2)
let make_mul f1 f2 = MultExpr(f1,f2)
let make_div f1 f2 = DivExpr(f1,f2)
let make_max f1 f2 = MaxExpr(f1,f2)
let make_min f1 f2 = MinExpr(f1,f2)
let make_float f = ConstExpr f
let make_rank () = VarRank 1.0
let make_aggr () = VarAggr 1.0


(*compute that recurssivly calls things until it gets down to basic float, based on arithexpr*)
let rec compute (f : formula) (rank : float) (agg : float) = 
match f with
| ConstExpr f -> f 
| AddExpr (e1,e2) -> (compute (e1) (rank) (agg)) +. (compute (e2) (rank) (agg))
| MultExpr (e1,e2) -> (compute e1 rank agg) *. (compute e2 rank agg)
| DivExpr (e1, e2) -> (compute e1 rank agg) /. (compute e2 rank agg)
| SubExpr (e1, e2) -> (compute e1 rank agg) -. (compute e2 rank agg)
| MinExpr (e1, e2) -> if (compute e1 rank agg) < (compute e2 rank agg) then (compute e1 rank agg) else (compute e2 rank agg)
| MaxExpr (e1, e2) -> if (compute e2 rank agg) < (compute e1 rank agg) then (compute e1 rank agg) else (compute e2 rank agg)
| VarRank e1 -> rank
| VarAggr e1-> agg


(*basic rank funtion that just keeps track of indexes*)
let rec rank (c : 'a) (default : float) (ls : 'a list) = 
    let rec rank_help c deaf ls index =
    match ls with
    | [] -> deaf
    | h::t -> if h = c then (index +. 1.0) else (rank_help c deaf t (index +. 1.0))
in rank_help c default ls 0.0


(*basic score section that calls compute and rank inside of its recurssive call to fill parameters*)
let rec score (c : 'a) (agg : float) (f : formula) (n : float) (ballots : 'a list list) =
match ballots with
| []-> agg
| h::t -> score c (compute f (rank c n h) agg) f n t


(*loops through cs and calcs the score at each value
uses a nested function to keep track of the ending list*)
let rec score_all (cs : 'a list) (init : float) (f : formula) (ballots : 'a list list) : ('a * float) list = 
let rec score_all_help cst init f ballots list = 
match cst with
| []-> List.rev list
| h::t -> score_all_help t init f ballots ((h,score h init f (float_of_int(List.length cs)) ballots)::list)
in score_all_help cs init f ballots []

