### Feedback for HW1

Run on February 23, 23:48:35 PM.

+ Pass: Change into directory "hw1".

+ Pass: Check that file "ballot.ml" exists.

+ Pass: Compile check for ballot.ml

+ Pass: 
Check that the result of evaluating
   ```
   ballots_from_lines []
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   ballots_from_lines [""]
   ```
   matches the pattern `[[]]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   ballots_from_lines ["a";"";"b,c"]
   ```
   matches the pattern `[["a"]; []; ["b";"c"]]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   first_error [] []
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   first_error [] [[];[]]
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   first_error [0] [[]]
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   first_error [0] [[0]]
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   first_error [0] [[2]]
   ```
   matches the pattern `Some 1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   first_error [0] [[]; [4]]
   ```
   matches the pattern `Some 2`.

   




+ Pass: 
Check that the result of evaluating
   ```
   pad 2 "a"
   ```
   matches the pattern `"a "`.

   




+ Pass: 
Check that the result of evaluating
   ```
   pad 2 "abc"
   ```
   matches the pattern `"abc"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   pad 0 ""
   ```
   matches the pattern `""`.

   




+ Pass: 
Check that the result of evaluating
   ```
   pad 3 ""
   ```
   matches the pattern `"   "`.

   




+ Pass: 
Check that the result of evaluating
   ```
   pad (-1) "anything"
   ```
   matches the pattern `"anything"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   max_len []
   ```
   matches the pattern `0`.

   




+ Pass: 
Check that the result of evaluating
   ```
   max_len [("a",0.)]
   ```
   matches the pattern `1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   max_len [("abc",0.); ("ab",1.)]
   ```
   matches the pattern `3`.

   




+ Pass: 
Check that the result of evaluating
   ```
   max_len [("a",3.); ("exterminate!",1.414); ("rtb",3e+14)]
   ```
   matches the pattern `12`.

   




+ Pass: Check that file "rank.ml" exists.

+ Pass: Compile check for rank.ml

+ Pass: 
Check that the result of evaluating
   ```
   rank 42 2.71828 []
   ```
   matches the pattern `2.71828`.

   




+ Pass: 
Check that the result of evaluating
   ```
   rank "peekaboo" 4. ["I see you"; "peekaboo"]
   ```
   matches the pattern `2.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   rank "a" 7. ["b";"b";"a";"a"]
   ```
   matches the pattern `3.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   rank 0 3.14 [1;2;3;4]
   ```
   matches the pattern `3.14`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_aggr () <> make_rank ()
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_rank () <> make_float 0.
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_float 0. <> make_float 1.
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_mul (make_float 1.) (make_float 0.) <> make_mul (make_float 1.) (make_float 1.)
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_mul (make_float 1.) (make_float 0.) <> make_div (make_float 1.) (make_float 0.)
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_max (make_float 1.) (make_float 0.) <> make_min (make_float 1.) (make_float 0.)
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_max (make_float 1.) (make_float 0.) <> make_add (make_float 1.) (make_float 0.)
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   make_add (make_float 0.) (make_float 1.) <> make_sub (make_float 0.) (make_float 1.)
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_rank ()) 1. 10.
   ```
   matches the pattern `1.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_aggr ()) 1. 10.
   ```
   matches the pattern `10.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_float 17.) 1. 10.
   ```
   matches the pattern `17.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_sub (make_rank ()) (make_float 1.)) 0. 10.
   ```
   matches the pattern `-1.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_div (make_rank ()) (make_aggr ())) 1. 10.
   ```
   matches the pattern `0.1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_add (make_aggr ()) (make_float 63.)) 1. 32.
   ```
   matches the pattern `95.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_max (make_rank ()) (make_aggr ())) 1. 10.
   ```
   matches the pattern `10.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_min (make_float 5.) (make_rank ())) 3. 1.
   ```
   matches the pattern `3.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_add (make_min (make_float 3.) (make_rank ())) (make_aggr ())) 1. 10.
   ```
   matches the pattern `11.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   compute (make_mul (make_float 3.) (make_float 2.)) 10. 10.
   ```
   matches the pattern `6.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score "a" 0. (make_add (make_rank ()) (make_aggr ())) 10. []
   ```
   matches the pattern `0.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score "a" 0. (make_add (make_rank ()) (make_aggr ())) 10. [[]]
   ```
   matches the pattern `10.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score "a" 0. (make_add (make_rank ()) (make_aggr ())) 10. [["a"]]
   ```
   matches the pattern `1.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score "a" 0. (make_add (make_rank ()) (make_aggr ())) 10. [["a"];["b";"a"]]
   ```
   matches the pattern `3.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score "a" 1. (make_mul (make_rank ()) (make_aggr ())) 10. [["a"];["b";"a"]]
   ```
   matches the pattern `2.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score "a" 1. (make_mul (make_rank ()) (make_aggr ())) 10. [["a"];["b";"a"]; []]
   ```
   matches the pattern `20.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score_all [] 0. (make_float 0.) []
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score_all ["a"] 0. (make_float 1.) []
   ```
   matches the pattern `[("a",0.)]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score_all ["a";"b"] 0. (make_float 1.) []
   ```
   matches the pattern `[("a",0.); ("b",0.)]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score_all ["a";"b"] 0. (make_rank ()) [["a"]]
   ```
   matches the pattern `[("a",1.); ("b",2.)]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score_all ["a";"b";"c"] 0. (make_add (make_rank ()) (make_aggr ())) [["a"]; ["b";"c"]]
   ```
   matches the pattern `[("a",4.);("b",4.);("c",5.)]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   score_all ["a";"b";"c"] 1. (make_mul (make_rank ()) (make_aggr ())) [["a"]; ["a"]; ["b";"a"]]
   ```
   matches the pattern `[("a",2.);("b",9.);("c",27.)]`.

   




