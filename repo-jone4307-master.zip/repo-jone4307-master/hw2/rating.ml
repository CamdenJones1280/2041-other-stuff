type uh = int
type ih = int

(*record with the fields of the infromation we are tring to pull according to the write up
list of user numbers, list of ratings, list of item handles, associating list of handles and item names
associating list of handles and descriptions*)
type db = {
  user : int list; 
  ratings : int list; 
  inthandle : int list; 
  handles_names : (int * string) list;
  handles_descrip : (int * string) list;
  user_item : (int * int) list
  }

exception LineFormatError
exception ItemError
exception RatingError

(*line formatting checking function, helper for from_file, checks the first letter and if the next
  part is a number and returns true or false after it checks for errors for next indexes*)
let format_check line = 
  let check_list = String.split_on_char ',' line in 
  if (List.nth check_list 0 = "i") && (List.length check_list = 4) then 
    try int_of_string(List.nth check_list 1) |> ignore; true with Failure _ -> false
  else if (List.nth check_list 0 = "r") && (List.length check_list = 4) then 
    (try int_of_string(List.nth check_list 1) |> ignore; true with Failure _ -> false) &&
    (try int_of_string(List.nth check_list 2) |> ignore; true with Failure _ -> false) &&
    (try float_of_string(List.nth check_list 3) |> ignore; true with Failure _ -> false)
  else false

(*checks to see if item is in the file already and returns false if its not in the list
  works for checking both the same handle and short name because were just passing in a list, helper for db_make*)
let rec item_check list = match list with
| [] -> false
| h::t -> if List.mem h t then true else item_check t

(*helper for make db that look for rating error*)
let rec rating_check list a b = match list with 
| [] -> true
| h::t -> (List.exists ((<>) a ) list) || (List.exists ((<>) b ) list)

(*helper that looks for rating error, non existant item*)
let rec rating_check2 list item = List.mem item list

(*makes db from combiled lists, helper for from_file, uses helpers of item check and rating check*)
let db_make user ratings inthandle handles_names handles_descrip user_item =
  if (item_check (snd(List.split handles_names))) || (item_check (fst(List.split handles_names))) then raise ItemError 
  else if rating_check (ratings) (1) (-1) then 
  {user = user; 
    ratings = ratings; 
    inthandle = inthandle; 
    handles_names = handles_names;
    handles_descrip = handles_descrip;
    user_item = user_item}
else raise RatingError

(*from file function start, reads data from file, checks for errors and writes data to db*)
let from_file f =  
  let ic = open_in f in 
  let next_line ()= try Some (input_line ic) with End_of_file -> None in
  let rec file_loop user ratings inthandle handles_names handles_descrip user_item = match next_line () with 
  | None -> db_make user ratings inthandle handles_names handles_descrip user_item
  | Some k -> if format_check k then 
    let string_list = String.split_on_char ',' k in if (List.nth string_list 0 = "i") then 
      file_loop user ratings (int_of_string(List.nth string_list 1)::inthandle) 
  ((int_of_string(List.nth string_list 1) , List.nth string_list 2)::handles_names)
  ((int_of_string(List.nth string_list 1) , List.nth string_list 3)::handles_descrip) user_item
  else if rating_check2 (inthandle) (int_of_string(List.nth string_list 2)) then
    if rating_check2 (user_item) (int_of_string(List.nth string_list 1) , int_of_string(List.nth string_list 2)) 
    then raise RatingError
  else if List.mem (int_of_string(List.nth string_list 1)) user then 
    try file_loop user (int_of_string(List.nth string_list 3)::ratings)
    (inthandle) (handles_names) (handles_descrip) 
    ((int_of_string(List.nth string_list 1) , int_of_string(List.nth string_list 2))::user_item)
  with Failure _ -> raise RatingError
else 
    try file_loop (int_of_string(List.nth string_list 1)::user) (int_of_string(List.nth string_list 3)::ratings)
  (inthandle) (handles_names) (handles_descrip) 
  ((int_of_string(List.nth string_list 1) , int_of_string(List.nth string_list 2))::user_item)
  with Failure _ -> raise RatingError 
  else raise RatingError
  else raise LineFormatError
   in
  file_loop [] [] [] [] [] []

(*uses list.assoc to run throuh data base list and return the name*)
let iname_from_handle d ih = List.assoc ih d.handles_names

(*uses list.assoc to run throught the data base list and return the description*)
let description_from_handle d ih = List.assoc ih d.handles_descrip

(*uses list.assoc_opt to run through the new data base list after i stitch it together backwards*)
let handle_from_iname d name = List.assoc_opt name (List.combine (snd(List.split d.handles_names)) (fst(List.split d.handles_names)))

(*finds the index at witch the rating occurs and then pulls the raiting from that index to return*)
let get d i u = 
  let rec count d i u c (list : (ih * ih) list) = match list with 
| [] -> 0.0
| (a,b)::t -> if (a = u) && (b = i) then float_of_int (List.nth d.ratings c) else count d i u (c+1) t
in count d i u 0 d.user_item

(*simply returns the list from the data base*)
let get_items d = d.inthandle

(*simply returns the list from the data base*)
let get_users d = d.user

(*loops through the list pulling matching value and pairing it with its rating*)
let get_item d i =
  let rec helper dataList i list = match dataList with
  | [] -> if list = [] then raise Not_found else List.rev list
  | (a,b)::t -> if a = i then helper t i ((b , (get d i b))::list) else helper t i list
  in helper (List.combine (snd(List.split d.user_item)) (fst(List.split d.user_item))) i []
