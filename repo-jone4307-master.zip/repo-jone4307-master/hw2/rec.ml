(* rec.ml *)
(* read a rating database (.csv file) *)
(* and find the k "most similar" items *)

let get_db_file () =
  let () = print_string "Enter name of ratings file: " in
  let rfname = read_line () in
  Rating.from_file rfname

let get_search_handle rdb =
  let () = print_string "Enter name of item to search for: " in
  let iname = read_line () in
  match Rating.handle_from_iname rdb iname with Some ih -> ih | None -> failwith "not found"

let get_num_matches () =
  let () = print_string "How many suggestions do you want? (1-5): " in read_int ()

let ask_again () =
  let () = print_string "Make another recommendation? (y/n): " in
  let ans = read_line () in (String.lowercase_ascii ans) = "y"

let print_out topk rdb = 
  Printf.printf "\n#\tscore   name: description\n==\t======  ===================\n";
let rec help topk rdb c = match topk with
| [] -> ()
| h::t -> Printf.printf "%d)\t%4.3f\t%s:%s\n" (c) (fst h) (Rating.iname_from_handle rdb (snd(h))) (Rating.description_from_handle rdb (snd(h)));
help t rdb (c+1) in help topk rdb 1 

let rec main_loop rdb =
  let ih = get_search_handle rdb in
  let k = get_num_matches () in
  let topk = Similar.top_k rdb k ih in
  let () = print_out topk rdb in
  if ask_again () then main_loop rdb else ()

(*let () = main_loop (get_db_file ())*)
