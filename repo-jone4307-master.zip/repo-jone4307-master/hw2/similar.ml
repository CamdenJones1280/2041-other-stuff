(*similarity between item handles, uses rating functions as well as higher order functions*)
let similarity db i1 i2 = 
  List.fold_left(fun acc u -> acc +. ((Rating.get db i1 u) *. (Rating.get db i2 u))) 0.0 (Rating.get_users db) /. 
  (sqrt(
  float_of_int((List.length (List.fold_left(fun acc u -> if (Rating.get db i1 u) <> 0.0 then (Rating.get db i1 u)::acc else acc) [] (Rating.get_users db)))) *.
  float_of_int((List.length (List.fold_left(fun acc u -> if (Rating.get db i2 u) <> 0.0 then (Rating.get db i2 u)::acc else acc) [] (Rating.get_users db)))) ))

  (*makes (similarity * handles) list, then sorts it, then runs loop on it grabbing the highest element that while still under k
  items, uses higher order functions and nested function*)
  let top_k db k it = 
    let rec help db k it curr list1 list2 =
      if curr < k then try (help db k it (curr + 1) ((List.nth list2 curr)::list1) list2) with Failure _ -> List.rev list1
      else List.rev list1
    in help db (k+1) it 1 [] (List.rev (List.sort compare (List.fold_left(fun acc i -> ((similarity db it i), i)::acc) [] (Rating.get_items db))))
