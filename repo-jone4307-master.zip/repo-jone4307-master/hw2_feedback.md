### Feedback for HW2

Run on March 17, 21:31:17 PM.

+ Pass: Change into directory "hw2".

+ Pass: Check that file "rating.ml" exists.

+ Pass: Compile check for rating.ml

+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "lerr1.csv" in false with LineFormatError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "lerr2.csv" in false with LineFormatError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "lerr3.csv" in false with LineFormatError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "lerr4.csv" in false with LineFormatError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "lerr5.csv" in false with LineFormatError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "lerr6.csv" in false with LineFormatError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "ierr1.csv" in false with ItemError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "ierr2.csv" in false with ItemError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "rerr1.csv" in false with RatingError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "rerr2.csv" in false with RatingError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "rerr3.csv" in false with RatingError -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "empty.csv" in true with _ -> false
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "ok1.csv" in true with _ -> false
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = from_file "ok2.csv" in true with _ -> false
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   iname_from_handle (from_file "ok1.csv") 4
   ```
   matches the pattern `"four"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try iname_from_handle (from_file "ok1.csv") 1 with Not_found -> "Yay!"
   ```
   matches the pattern `"Yay!"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   iname_from_handle (from_file "ok2.csv") 314159
   ```
   matches the pattern `"pi"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   handle_from_iname (from_file "ok1.csv") "thirteen"
   ```
   matches the pattern `Some 13`.

   




+ Pass: 
Check that the result of evaluating
   ```
   handle_from_iname (from_file "ok1.csv") "slitheen"
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   handle_from_iname (from_file "ok2.csv") "pi"
   ```
   matches the pattern `Some 314159`.

   




+ Pass: 
Check that the result of evaluating
   ```
   description_from_handle (from_file "ok1.csv") 4
   ```
   matches the pattern `"Tom Baker"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try description_from_handle (from_file "ok1.csv") 5 with Not_found -> "TARDIS"
   ```
   matches the pattern `"TARDIS"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   description_from_handle (from_file "ok2.csv") 271828
   ```
   matches the pattern `"Euler's Constant"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   get_items (from_file "empty.csv")
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   List.sort (-) (get_items (from_file "ok1.csv"))
   ```
   matches the pattern `List.sort (-) [13;12;11;10;9;4]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   List.sort (-) (get_items (from_file "ok2.csv"))
   ```
   matches the pattern `List.sort (-) [314159;271828;161803;3;2;1]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   get_users (from_file "empty.csv")
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   List.sort (-) (get_users (from_file "ok1.csv"))
   ```
   matches the pattern `List.sort (-) [101;102;103;104;105;106;107]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   List.sort (-) (get_users (from_file "ok2.csv"))
   ```
   matches the pattern `List.sort (-) [102;103;104]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   get (from_file "ok1.csv") 4 103
   ```
   matches the pattern `-1.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   get (from_file "ok1.csv") 4 106
   ```
   matches the pattern `0.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   get (from_file "ok2.csv") 314159 102
   ```
   matches the pattern `1.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   List.sort compare (get_item (from_file "ok1.csv") 4)
   ```
   matches the pattern `List.sort compare [(105, -1.); (104, 1.); (103, -1.); (101, 1.)]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   List.sort compare (get_item (from_file "ok1.csv") 13)
   ```
   matches the pattern `List.sort compare [(105, 1.); (101, 1.)]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   List.sort compare (get_item (from_file "ok2.csv") 314159)
   ```
   matches the pattern `List.sort compare [(103, 1.); (102, 1.)]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try get_item (from_file "ok2.csv") 345 with Not_found -> [(min_int,Float.infinity)]
   ```
   matches the pattern `[(min_int,Float.infinity)]`.

   




+ Pass: Check that file "similar.ml" exists.

+ Pass: Compile check for similar.ml

+ Pass: 
Check that the result of evaluating
   ```
   abs_float (similarity Rating.DB 1 2 -. (-0.408248290463862962)) < 1e-7
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   abs_float (similarity Rating.DB 2 3 -. (0.577350269189625842)) < 1e-7
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   abs_float (similarity Rating.DB 1 3 -. (0.)) < 1e-7
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   abs_float (similarity Rating.DB 4 4 -. (1.)) < 1e-7
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   abs_float (similarity Rating.DB 5 4 -. (0.707106781186547462)) < 1e-7
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   top_k Rating.DB 0 1 =? []
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   top_k Rating.DB 3 1 =? [(0., 5); (0., 3); (-0.408248290463862962, 2)]
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   top_k Rating.DB 2 4 =? [(0.707106781186547462, 5); (0.408248290463862962, 2)]
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   top_k Rating.DB 5 3 =? [(0.577350269189625842, 2); (0.353553390593273731, 4); (0., 5); (0., 1)]
   ```
   matches the pattern `true`.

   




+ Pass: Check that file "rec.ml" exists.

+ Pass: Compile check for rec.ml

