## Feedback for HW3

Run on April 08, 19:59:56 PM.

+ Pass: Change into directory "hw3".

+ Pass: Check that file "program.ml" exists.

+ Pass: Check that file "parser.ml" exists.

+ Pass: Check that file "interpreter.ml" exists.

+ Pass: Check that hw files compile without errors

## Part 1: Adding readint expressions

+ Pass: Check that expression `Program.Readint` following file /dev/null has type `Program.expr`

+ Pass: 
Check that the result of evaluating
   ```
   typeof Readint []
   ```
   matches the pattern `IntT`.

   




**DID YOU INCLUDE AN `eval` CLAUSE FOR READINT?**

## Part 2: Parsing read expressions

+ Pass: Check that expression `Parser.READ` following file /dev/null has type `Parser.token`

+ Pass: 
Check that the result of evaluating
   ```
   tokenize_string "readint"
   ```
   matches the pattern `READ`.

   




+ Pass: 
Check that the result of evaluating
   ```
   _parser [READ;CP]
   ```
   matches the pattern `(Readint,[CP])`.

   




## Part 3: Adding integer list expressions

### Adding lists to expr

+ Pass: Check that expression `(Program.ListC [])` following file /dev/null has type `Program.expr`

+ Pass: Check that expression `(Program.Head (Program.Cons (Program.Readint, Program.Tail (Program.ListC [1; 2]))))` following file /dev/null has type `Program.expr`

+ Pass: Check that expression `Program.ListT` following file /dev/null has type `Program.expType`

### Type checking list 

+ Pass: 
Check that the result of evaluating
   ```
   typeof (Cons(Head (ListC [1;2]), Tail (ListC [3;4]))) []
   ```
   matches the pattern `ListT`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Cons(BoolC false, ListC [])) [] in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Tail (IntC 0)) [] in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Head (IntC 0)) [] in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Cons(IntC 0, IntC 1)) [] in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




### Evaluating expressions with lists

+ Pass: Check that expression `Program.ListR []` following file /dev/null has type `Program.result`

+ Pass: 
Check that the result of evaluating
   ```
   eval (Tail(Cons(Head(Seq [Set ("x", IntC 17); ListC [1;2]]), Cons(Name "x", ListC [])))) [("x", IntR 5); ("y", ListR [1;2])]
   ```
   matches the pattern `(ListR [17], [("x",IntR 17); ("y", ListR [1;2])])`.

   




## Part 4: Parsing integer lists

### Adding list tokens

+ Pass: Check that expression `[Parser.LB; Parser.RB; Parser.CONS; Parser.HEAD; Parser.TAIL; Parser.LIST]` following file /dev/null has type `Parser.token list`

+ Pass: 
Check that the result of evaluating
   ```
   List.map tokenize_string ["["; "]"; "cons"; "head"; "tail"; "list"]
   ```
   matches the pattern `[LB; RB; CONS; HEAD; TAIL; LIST]`.

   




### Parsing list expressions

+ Pass: 
Check that the result of evaluating
   ```
   _parse_type_expr [LIST]
   ```
   matches the pattern `(ListT,[])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = _parser [LB; OP; PLUS; ICONST 1; ICONST 1; CP; RB] in false with _ -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   parse_program (tokens (wordlist example5))
   ```
   matches the pattern `
Let ("rev",
Fun ("in", ListT,
Let ("out", ListC [],
  Seq
    [While (Not (Eq (Name "in", ListC [])),
      Seq
        [Set ("out", Cons (Head (Name "in"), Name "out"));
          Set ("in", Tail (Name "in"))]);
            Name "out"])),
Apply (Name "rev", ListC [1; 2; 3; 4; 5]))
`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = parse_program (tokens (wordlist "[1 2 ")) in false with _ -> true
   ```
   matches the pattern `true`.

   




## Part 5: Adding Recursive Function Expressions

### Adding recursive function constructors

+ Pass: Check that expression `Program.Funrec("pow2","n",Program.IntT,Program.IntT,Program.If(Program.Eq (Program.Name "n", Program.IntC 0), Program.IntC 1, Program.Mul (Program.IntC 2, Program.Apply(Program.Name "pow2", Program.Sub (Program.Name "n", Program.IntC 1)))))` following file /dev/null has type `Program.expr`

+ Pass: Check that expression `Program.ClosureRec(Program.If(Program.Eq (Program.Name "ls", Program.ListC []), Program.IntC 0, Program.Apply(Program.Name "lw", Program.Tail (Program.Name "ls"))),"lw","l",[])` following file /dev/null has type `Program.result`

### Type checking recursive functions

+ Pass: 
Check that the result of evaluating
   ```
   typeof (Funrec("pow2","n",IntT,IntT,If(Eq (Name "n", IntC 0), IntC 1, Mul (IntC 2, Apply(Name "pow2", Sub (Name "n", IntC 1)))))) []
   ```
   matches the pattern `FunT(IntT,IntT)`.

   




+ Pass: 
Check that the result of evaluating
   ```
   typeof (Funrec("lw","ls",IntT,ListT,If(Eq (Name "ls", ListC []), IntC 0, Apply(Name "lw", Tail (Name "ls"))))) []
   ```
   matches the pattern `FunT(ListT,IntT)`.

   




+ Pass: 
Check that the result of evaluating
   ```
   typeof (Funrec("tightloop","x",BoolT,IntT,Apply(Name "tightloop", Name "x"))) []
   ```
   matches the pattern `FunT(IntT,BoolT)`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Funrec("f","x",ListT,IntT,Name "x")) [] in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Funrec("f","b",IntT,IntT,Apply(Name "f", BoolC false))) []in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Funrec("f","n",ListT,IntT,And(BoolC true, Apply(Name "f", IntC 0)))) [] in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = typeof (Funrec("f","x",IntT,BoolT,Add(IntC 0, Name "x"))) [] in false with TypeError _ -> true
   ```
   matches the pattern `true`.

   




### Evaluating recursive functions

+ Pass: 
Check that the result of evaluating
   ```
   evalFunc (Funrec("f","b",BoolT,BoolT,If(Name "b",BoolC true,Apply(Name "f",Name "b")))) (BoolC true) []
   ```
   matches the pattern `(BoolR true, [])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = evalFunc (Funrec("f","b",BoolT,BoolT,If(Name "b",BoolC true,Apply(Name "f",Name "b")))) (BoolC true) [] in false with Stack_overflow -> true
   ```
   matches the pattern `false`.

   




+ Pass: 
Check that the result of evaluating
   ```
   evalFunc (Funrec("f","b",IntT,BoolT,If(Name "b",IntC 0,Add(IntC 1,Apply(Name "f",BoolC true))))) (BoolC true) []
   ```
   matches the pattern `(IntR 0, [])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   evalFunc (Funrec("f","b",IntT,BoolT,If(Name "b",IntC 0,Add(IntC 1,Apply(Name "f",BoolC true))))) (BoolC false) []
   ```
   matches the pattern `(IntR 1, [])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   evalFunc (Funrec("f","n",IntT,IntT,If(Eq(Name "n",IntC 0),IntC 1,Mul(IntC 2, Apply(Name "f",Sub(Name "n",IntC 1)))))) (IntC 7) [("z",UnitR)]
   ```
   matches the pattern `(IntR 128, [("z",UnitR)])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   evalFunc (Funrec("f","n",IntT,IntT,If(Eq(Name "n",IntC 0),IntC 1,Mul(IntC 2, Apply(Name "f",Sub(Name "n",IntC 1)))))) (Name "m") [("m",IntR 5);("z",UnitR)]
   ```
   matches the pattern `(IntR 32, [("m",IntR 5);("z",UnitR)])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   evalFunc (Funrec("f","n",IntT,IntT,If(Eq(Name "n",IntC 0),IntC 1,Mul(IntC 2, Apply(Name "f",Sub(Name "n",IntC 1)))))) (Seq [Set("z",IntC 3); Name "m"]) [("m",IntR 5);("z",IntR 1)]
   ```
   matches the pattern `(IntR 32, [("m",IntR 5);("z",IntR 3)])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   evalFunc (Fun("b",BoolT,Name "b")) (BoolC true) [("b",UnitR)]
   ```
   matches the pattern `(BoolR true, [("b",UnitR)])`.

   




## Part 6: Parsing recursive functions

+ Pass: Check that expression `Parser.LETREC` following file /dev/null has type `Parser.token`

+ Pass: 
Check that the result of evaluating
   ```
   tokenize_string "letrec"
   ```
   matches the pattern `LETREC`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = _parser [OP;LETREC;ICONST 0] in false with SyntaxError "letrec"-> true | _ -> false
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = _parser [OP;LETREC;ID "s";ICONST 1] in false with SyntaxError "letrec"-> true | _ -> false
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = _parser [OP;LETREC;ID "f";COLON;INT;ICONST 1;ICONST 2;CP] in 0 with SyntaxError _ -> 1 | _ -> 0
   ```
   matches the pattern `1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = _parser [OP;LETREC;ID "f";COLON;INT;OP;FUN;ID "x";COLON;INT;ID "x";CP;CP] in 0 with SyntaxError _ -> 1 | _ -> 0
   ```
   matches the pattern `1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try let _ = _parser [OP;LETREC;ID "f";COLON;INT;OP;FUN;ID "x";COLON;INT;ID "x";CP;ICONST 1] in 0 with SyntaxError "parser: missing closing paren." -> 1 | _ -> 0
   ```
   matches the pattern `1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   _parser [OP;LETREC;ID "f";COLON;INT;OP;FUN;ID "x";COLON;INT;ID "x";CP;ICONST 1;CP]
   ```
   matches the pattern `(Let ("f", Funrec ("f", "x", IntT, IntT, Name "x"), IntC 1), [])`.

   




+ Pass: 
Check that the result of evaluating
   ```
   _parser [OP;LETREC;ID "f";COLON;BOOL;OP;FUN;ID "x";COLON;INT;BCONST false;CP;ICONST 1;CP]
   ```
   matches the pattern `(Let ("f", Funrec ("f", "x", BoolT, IntT, BoolC false), IntC 1), [])`.

   




