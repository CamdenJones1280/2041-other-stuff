## Assessment for Lab 0

Run on January 19, 09:07:34 AM.

+  _1_ / _1_ : Pass: Change into directory "lab0".

+  _1_ / _1_ : Pass: Check that file "nsum.ml" exists.

+  _1_ / _1_ : Pass: Check that an OCaml file "nsum.ml" has no syntax or type errors.

    OCaml file "nsum.ml" has no syntax or type errors.



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   nsum 4
   ```
   matches the pattern `10`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   nsum 0
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: Check that file "lab0.txt" exists.

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   try nsum (-1) with Stack_overflow -> (-1)
   ```
   matches the pattern `0`.

   




#### Subtotal: _7_ / _7_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

