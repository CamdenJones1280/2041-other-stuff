let rec sumsquares (x) =
if x <= 0 then 0
else  sumsquares (x-1) + (x * x)

let rec sumodds n =
if n <= 1 then 1
else if n mod 2 = 0 then 0 + sumodds (n-1)
else sumodds (n-1) + n

(*helper to third problem*)
let rec helper s c n =
if n >= String.length s then 0
else if s.[n] = c then helper s c (n+1) + 1 
else helper s c (n+1)

let rec countc s c =
helper s c 0

let rec rightjustify w n =
if String.length (string_of_int n) >= w then string_of_int n
else " " ^ rightjustify (w-1) n




