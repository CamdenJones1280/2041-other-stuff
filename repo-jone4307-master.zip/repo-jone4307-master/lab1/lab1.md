# Lab 1: Beginning OCaml

*CSci 2041: Advanced Programming Principles, Spring 22 (Section 1)*

**Due:** Tuesday, January 25 at 11:59pm (CST)

# Interacting with an OCaml program

At the start of the lab, cd to the public lab repository (you probably cloned it to `~/csci2041/labs2041` last week) and do a `git pull` to
make sure you have the latest lab exercise materials.  You should find a new directory
there named `lab1`, and inside that directory will be a file named `lab1.ml`.
Copy the directory and file to your group or personal repository, and remember
to do a `git add` on both.  

In this class, a typical method of developing and debugging OCaml programs will involve three windows or tabs:

+ You will write code in a text editor; several commonly used editors (e.g. vscode, emacs, gedit, atom)
  understand OCaml syntax and support syntax highlighting to help format your code.
  Open `lab1.ml` in vscode (or your text editor of choice)

+ A terminal window with a shell in the directory where your code
  resides.  You can build and run the program from the shell using the
  command `ocamlc`.  To try building an executable for the program in `lab1.ml`, type
  ```sh
  % ocamlc -o lab1 lab1.ml
  ```
  at the shell prompt now.  The compiler will fail, since the program has
  several deliberate bugs; we'll get to these a bit more in a moment.

+ An ocaml top-level shell.  OCaml has a top-level
  Read-Evaluate-Print-Loop (REPL) shell that is included by default as
  `ocaml`, or we can use the nicer `utop` REPL, which provides
  name-completion, command history, and syntax highlighting, but otherwise functions in
  the same way as `ocaml`.  To load a file in `utop`, we first start
  utop in a terminal window:
  ```
  % utop
  ```
  Then at the `utop` shell prompt, we can load a file using the `#use`
  _directive_.  A _directive_ is a command given to the REPL shell
  that is not a valid part of an OCaml program: we'll never type
  `#use` in a `.ml` file.  To attempt to compile and test out
  `lab1.ml` in `utop`, type the following at the `utop` prompt:
  ```
  utop # #use "lab1.ml" ;;
  ```
  `utop` will attempt to compile `lab1.ml` and will also print out an
  error message.   (The `;;` delimiter is also a command to the REPL,
  telling it to compile and evaluate whatever you've typed so far.  It
  should also never be used in a `.ml` file).

# 1. Debugging some errors

Now that we've got our programming environment set up, with the
editor, terminal and REPL loop, let's go back and look at what
`ocamlc` told us when we tried to compile `lab1.ml`.  In that
terminal window, you should see the error message:
```
File "lab1.ml", line 4, characters 17-18:
Error: Syntax error: operator expected.
```
Back in your editor, find the 4th line:
```
let zero = (-2 + )
```
We see that immediately before characters 16 and 17 there is a `+` but
there is no argument to `+`.  This is a syntax error, because there's
no way to read this as a valid expression (to _parse_ the line).  You
should fix this error by supplying a second argument to `+` that will
bind the name `zero` to the expected value.

If we try to build the program again using `ocamlc -o lab1 lab1.ml`, we'll
see a new error message.  This is progress! But we're not done yet:
```
File "lab1.ml", line 6, characters 4-7:
Error: Syntax error
```
Go back and find line 6 in the text editor window.  It might look like
this line is OK as a let expression: it defines a function that
returns its argument.  The problem here is that `fun` is an OCaml
keyword and can't be used as a variable name.  (Similarly, `function`
is also a keyword and can't be used.)  Choosing a new name for the
function, e.g. `fn` will fix this error; go ahead and do this.

Building again, you'll find another Syntax Error on the next line.
See if you can figure out from looking at the line in your text editor
what the problem is.  (Fixing this problem will also require changing
another line later in the program.)  Another very similar syntax error
appears on line 8.  You can again fix it by changing the name of a
variable, although this time the variable is an argument.

Once these syntax errors are cleared up, if you build again, you'll
see the error message:
```
File "lab1.ml", line 10, characters 17-18:
Error: Unbound value y
```
Find line 10 in the editor: can you see the problem?

The compiler is telling us that the let declaration on line 10 defines
a function, `mult`, which references the name `y`, but `y` has not
been bound (defined) before. Looking at the definition of `mult`, we
see that only one variable name appears on the left of the `=` sign,
but two names are used on the right.  If we add `y` to the list of
arguments, this error should go away; try it now.

The next compiler error looks very similar:
```
File "lab1.ml", line 12, characters 16-17:
Error: Unbound value x
```
Look at line 12 and see if you can fix the problem.

Moving on, we get an interesting error:
```
File "lab1.ml", line 14, characters 17-24:
Error: This expression has type string but an expression was expected of type
         int
```
Look at line 14; characters 17-24 are the string literal `"hello"`.
Why does OCaml "expect" an expression of type `int` here?  This is
because we're trying to give `"hello"` as an argument to the operator
`+`, which only operates on `int`s.  This is what's called a _type
error_, because we're calling a function or operator with an argument
whose expression evaluates to a different type than the one expected
by the callee.

What causes an error like this?  Well, either we're passing the wrong
arguments to the operator `+`, or, we're using the wrong operator.
Since it looks like this line of code is trying to concatenate the
arguments, we probably meant to call the string concatenation
operator, `^`.  Change this in the code and see what happens next.

If we now try to build the code, we get what looks like another type
error:
```
File "lab1.ml", line 16, characters 41-58:
Error: This expression has type int -> string
       but an expression was expected of type int
```
Looking at line 16, it seems that we are trying to take the last `t`
characters from the string `s`, by calling `String.sub` with the
arguments `s`, `last - t` and `t`.  But the compiler is complaining
about the "expression" `String.sub s last`.  What's going on?

The problem is that infix operators have a lower precedence
than function application, so instead of thinking we want to pass
`last - t` as an argument to `String.sub s`, the compiler thinks we
meant to pass `String.sub s last` as an argument to `-`.  We can fix
this with parentheses around `last - t` in order to clear up what the
arguments are to `-`.  Do this and try to build the file again.

Hey!  we made it!  Let's execute the program and see what happens.  At
the terminal shell prompt, type:
```
% ./lab1
```
To run the executable `lab1` produced by the compiler.  You should see:
```
Fatal error: exception Invalid_argument("index out of bounds")
```
Uh oh.  Now what?  This is an example of a _run-time error_, a program
bug that happens when we encounter conditions that the compiler can't
predict before hand.  What's going wrong here?  Let's switch to the
`utop` top-level shell and try to compile and evaluate `lab1.ml`:
```
utop # #use "lab1.ml" ;;
val zero : int = 0
val fn : 'a -> 'a = <fun>
val beginning : string -> char = <fun>          
val len : string -> int = <fun>
val mult : int -> int -> int = <fun>
val or3 : bool -> bool -> bool -> bool = <fun>
val helloworld : string = "helloworld"
val ending : string -> int -> string = <fun>
Exception: Invalid_argument "index out of bounds".
```
It looks like the run-time error is happening after we evaluate the
let declaration binding `ending`.  If we look in the text editor, the
next expression is:
```
let c = beginning ""
```
What's going on here?  The type of `beginning` is `string -> char`,
and we're calling it with `""`, a string; so there's not a type error
or a syntax error here.  If we look at the definition of `beginning`,
we see that `beginning s` returns `s.[0]`, that is, it tries to return
the character at index `0` of its argument.  Since the argument here
is the empty string, `""`, it doesn't have a character at index 0,
resulting in the `index out of bounds` exception.  We'll learn later
how to handle exceptions; for now you can go ahead and "fix" this
problem by commenting out the offending expression.  Compile and run the
program one last time, and declare victory!

_**Test cases:**_ No partial credit for this problem, `lab1.ml` must compile and run without errors while correctly binding all of the names it currently binds.

# 2. Writing new OCaml Functions

Now that we're experienced at understanding error messages, let's continue by writing some new Ocaml functions.  Create a file in your `lab1` directory called `functions.ml`.  You'll need to use `git add` to add it to your repository before you commit and push later.

### Sumthing good?

In episode 1.2 and the synchronous meeting we saw the function `sumup : int -> int` that adds the integers `0` through `n`.  Let's write some similar functions:

+ Add a definition (to `functions.ml`) for a function `sumsquares : int -> int` such that `sumsquares n` is the sum of the squares of the integers from `0` to `n`, e.g. `sumsquares 0` should evaluate to 0, `sumsquares 1` should evaluate to `1`, and `sumsquares 4` should evaluate to 1 + 4 + 9 + 16 = `30`.

+ Now add a definition for a function `sumodds` such that `sumodds n` sums only the odd numbers between 1 and `n`, eg `sumodds 1` should evaluate to `1`, sumodds `4` should evaluate to `1+3`, and `sumodds 8` should evaluate to 1 + 3 + 5 + 7 = `16`.

+ *Challenge:* We can generalize both of these functions to the functions `sumf : (int -> int) -> int -> int`, which takes a function `f : int->int` and an int `n` as arguments, and returns `f 0` + `f 1` + ... + `f n`.  In the first case, `f = (fun n -> n*n)` and in the second, `f = (fun n -> if n mod 2 = 1 then n else 0)`  Write a definition for the function `sumf`.  Some test cases include `sumf (fun n -> 1) 10` = `11`, `sumf (fun n -> 2*n) 5` = `30`, and `sumf (fun n -> (n land 1)*n) 8` = `16`.

### String things

+ Write a function `countc : string -> char -> int` such that `countc s c` counts the number of times character `c` appears in the string `s`.  So for example `countc "acab" 'a'` should evaluate to `2`; `countc "birdofprey" 'z'` should evaluate to `0`; and `countc "zzzzz" 'z'` should evaluate to 5.  Hint: you will probably find it useful to define a helper function that counts the number of times `c` appears between either the beginning of the string and a given index or the end of the string and a given index.  

+ Write a function `rightjustify : int -> int -> string` such that `rightjustify w n` returns a string representation of `n` padded with enough spaces in front so that the string has width `w`.  (If the string representation of `n` has length greater than `w`, no padding should be added).  So `rightjustify 5 123` should evaluate to the string `"  123"` and `rightjustify 1 314` should evaluate to the string `"314"`

_**Test Cases:**_ For full credit your solution should pass 11/14 of the example evaluations given above.

# 3. Vector functions

Let's finish this lab exercise by writing a few functions that deal with 2-dimensional vectors, represented as pairs of `float`s.   (As a reminder, a 2-dimensional vector is basically just an (x,y) point in space: its length is its
distance from the origin - (0,0)) Create a file named `vector.ml` in your `lab1` directory.  Open `vector.ml` in the text editor and try writing OCaml definitions for the following functions:

### `scale`

Scalar multiplication of a vector by a real number simply multiplies both
components by the scalar.  Write a definition for `scale : float -> float * float -> float * float`  so that:

+ `scale 3. (1., 2.)` evaluates to `(3., 6.)` and
+ `scale 2. (-1.,4.)` evaluates to `(-2.,8.)`.

### `length`

The length of a vector (a,b) is the square root of a * a  + b * b.  So if we define `length : (float*float) -> float` we should have:

+ `length (3.,4.)` should evaluate to `5.`
+ `length (5.,12.)` should evaluate to `13.`

(There is an OCaml function, `sqrt : float -> float`, that computes
the square root of a floating-point number.)

### `vec_add`

We can use OCaml's tuples to represent two-dimensional vectors as
pairs of `float`s.  Write the OCaml definition for the function
`vec_add : (float * float) -> (float * float) -> (float*float)` that
adds two vectors together.  Some sample evaluations:

+ `vec_add (1.0,2.5) (3.0,-1.0)` evaluates to `(4., 1.5)`
+ `vec_add (0.0,1.0) (2.0,2.0)` evaluates to `(2., 3.)`

### `dot`

Recall that the dot-product or inner product of two vectors is the sum of the
component-wise products, e.g. in "math" the dot product of (a,b) and (c,d) is
a×c+b×d.  Write the OCaml definition for the function `dot : (float * float) ->
(float * float) -> float` to compute the dot product of two 2-dimensional
vectors.  Some sample evaluations:

+ `dot (0.0,2.0) (1.0,3.14)` evaluates to `6.28`
+ `dot (1.0,-1.0) (3.0,4.0)` evaluates to `-1.`

### `perp`
Two vectors are perpendicular or orthogonal if their inner product is 0.  Write the OCaml definition for the function `perp : float*float
-> float*float -> bool` that returns true if its arguments are
perpendicular and false otherwise.  Sample evaluations:

+ `perp (0.,1.) (-1.,0.)` evaluates to `true`
+ `perp (1.,2.) (-1.,1.)` evaluates to `false`

For implementation simplicity, assume that the 0-vector `(0.,0.)` is
perpendicular to any vector, including itself.


Your solution must pass 6/10 test cases to get full credit for this problem.
