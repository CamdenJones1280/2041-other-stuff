let scale z (x,y) = 
(x *. z, y *.z)

let length (x,y) =
sqrt (x*.x +. y*.y)

let vec_add (x,y) (a,b) =
((x+.a),(y+.b))

