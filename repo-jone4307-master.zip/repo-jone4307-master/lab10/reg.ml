(* Lab 10 regular expressions *)

(* Not even the right type... *)
let emoticon_re = Str.regexp {|[^0-9]+[:;]+[)-]|}

let get_phone s = None

let hyperlinks s = []
