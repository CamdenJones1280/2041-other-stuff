## Assessment for Lab 10

Run on April 06, 08:28:21 AM.

+ Pass: Change into directory "lab10".

### Part 1: Streams

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take_s 5 (map_s (fun n -> 2*n+1) (nats 0))
   ```
   matches the pattern `[1; 3; 5; 7; 9]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take_s 2 (map_s String.uppercase_ascii (repeating "wow"))
   ```
   matches the pattern `["WOW"; "WOW"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take_s 3 (odds_s factorials)
   ```
   matches the pattern `[2; 24; 720]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take_s 4 (odds_s fibs)
   ```
   matches the pattern `[1; 2; 5; 13]`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   take_s 10 (natpairs (0,0))
   ```
   matches the pattern `[(0, 0); (0, 1); (1, 0); (0, 2); (1, 1); (2, 0); (0, 3); (1, 2); (2, 1); (3, 0)]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
- : (int * int) list =
[(0, 0); (1, -1); (2, -2); (3, -3); (4, -4); (5, -5); (6, -6); (7, -7);
 (8, -8); (9, -9)]

```



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take_s 4 (natpairs (4,5))
   ```
   matches the pattern `[(4, 5); (5, 4); (6, 3); (7, 2)]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   (pal_check "Abba") && (pal_check "dAD") && (pal_check "") && (pal_check "raceCar")
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   (pal_check "abc") || (pal_check "aB") || (pal_check "nomnomcookies")
   ```
   matches the pattern `false`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   take_s 3 (bstrings_s "a" "b")
   ```
   matches the pattern `[""; "a"; "b"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   take_s 7 (bstrings_s "foo" "bar")
   ```
   matches the pattern `[""; "foo"; "bar"; "foofoo"; "foobar"; "barfoo"; "barbar"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   take_s 3 (palindromes "Race" "Car")
   ```
   matches the pattern `[""; "RaceCar"; "RaceCarRaceCar"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   take_s 4 (palindromes "Mad" "Dame")
   ```
   matches the pattern `[""; "DameMad"; "DameMadDameMad"; "DameMadDameMadDameMad"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


#### Subtotal: _7_ / _12_

### Part 2: Lazy lists

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lztake 4 (lzmap (fun n -> 3*n) (lznats 0))
   ```
   matches the pattern `[0;3;6;9]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lztake 3 (lzmap (fun s -> s^"!") (lzrepeat "yass"))
   ```
   matches the pattern `["yass!"; "yass!"; "yass!"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lztake 4 (lz_odds (lzmerge lzfibs lzfact))
   ```
   matches the pattern `[1; 2; 6; 24]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lztake 3 (lz_odds (lznats 0))
   ```
   matches the pattern `[1; 3; 5]`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   lztake 3 (lz_natpairs (12,1))
   ```
   matches the pattern `[(12, 1); (13, 0); (0, 14)]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   lztake 4 (lz_natpairs (100,99))
   ```
   matches the pattern `[(100,99); (101, 98); (102, 97); (103, 96)]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   lztake 7 (lz_bstrings "0" "1")
   ```
   matches the pattern `[""; "0"; "1"; "00"; "01"; "10"; "11"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   lztake 6 (lz_bstrings "aa" "b")
   ```
   matches the pattern `["";"aa";"b";"aaaa";"aab";"baa"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   lztake 5 (lz_palindromes "dad" "dad")
   ```
   matches the pattern `[""; "dad"; "dad"; "daddad"; "daddad"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   lztake 4 (lz_palindromes "o" "so")
   ```
   matches the pattern `[""; "o"; "oo"; "oso"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


#### Subtotal: _4_ / _10_

### Part 3: Regular Expressions

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   Str.string_match emoticon_re "Sweet Christmas!" 0
   ```
   matches the pattern `false`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   Str.string_match emoticon_re "I understood that reference! :)" 0
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   Str.string_match emoticon_re "I am: inevitable. (And I... am iron man)" 0
   ```
   matches the pattern `false`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   Str.string_match emoticon_re "That was awful. ;-)" 0
   ```
   matches the pattern `true`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   get_phone "Hey, call me back at (505) 842-5325"
   ```
   matches the pattern `Some "(505) 842-5325"`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a option = None
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   get_phone "Call 1-800-GOT-JUNK"
   ```
   matches the pattern `None`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   get_phone "Joan Gabel, Ph.D. (612-626-1616) <upres@umn.edu>"
   ```
   matches the pattern `Some "612-626-1616"`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a option = None
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   get_phone "Call Mr. Plow: (234)-555-3226. That name again is Mr. Plow!"
   ```
   matches the pattern `Some "(234)-555-3226"`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a option = None
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   hyperlinks {|<a href="https://t.co">Twitter?</a> <a href = "http://is.gd">Short</a> href="blah.invalid"|}
   ```
   matches the pattern `["https://t.co"; "http://is.gd"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   hyperlinks {|"https://notinanhref/"|}
   ```
   matches the pattern `[]`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   hyperlinks {|href="http://technically.ok/"|}
   ```
   matches the pattern `["http://technically.ok/"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   hyperlinks {|href="nohttp://blah"|}
   ```
   matches the pattern `[]`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   hyperlinks {|href= "https://z.umn.edu/" href  ="http://goo.gl"|}
   ```
   matches the pattern `["https://z.umn.edu/";"http://goo.gl"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   hyperlinks {|href=http://noquotes.co hrefz="http://extrachars.to/" href=!"http://notequal.ai" href="https://yes.me/"|}
   ```
   matches the pattern `["https://yes.me/"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


#### Subtotal: _7_ / _14_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

