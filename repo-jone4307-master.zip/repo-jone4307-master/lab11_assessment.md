## Assessment for Lab 11

Run on April 13, 10:41:27 AM.

+ Fail: Change into directory "lab11".

     Directory "lab11" not found.

### Part 1: Induction Review

+  _0_ / _1_ : Fail: met an exception [Errno 2] No such file or directory: 'ninduction.md'

+  _0_ / _1_ : Fail: met an exception [Errno 2] No such file or directory: 'ninduction.md'

+  _0_ / _1_ : Fail: met an exception [Errno 2] No such file or directory: 'ninduction.md'

+  _0_ / _1_ : Fail: met an exception [Errno 2] No such file or directory: 'ninduction.md'

+  _0_ / _1_ : Fail: met an exception [Errno 2] No such file or directory: 'ninduction.md'

+  _0_ / _1_ : Fail: met an exception [Errno 2] No such file or directory: 'ninduction.md'

#### Subtotal: _0_ / _6_

### Part 2: Natural induction

+  _0_ / _1_ : Skip: Proof Goals: repeatlen.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Base Case: repeatlen.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Inductive Case: repeatlen.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Proof Goals: tr_fact.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Base Case: tr_fact.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Inductive Case: tr_fact.md

  This test was not run because of an earlier failing test.

#### Subtotal: _0_ / _6_

### Part 3: Structural induction on nat

+  _0_ / _1_ : Skip: Proof Goals: tr_nat.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Base Case: tr_nat.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Inductive Case: tr_nat.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Proof Goals: pow2_nat.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Base Case: pow2_nat.md

  This test was not run because of an earlier failing test.

+  _0_ / _1_ : Skip: Inductive Case: pow2_nat.md

  This test was not run because of an earlier failing test.

#### Subtotal: _0_ / _6_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

