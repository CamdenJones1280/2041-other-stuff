## Assessment for Lab 1

Run on January 26, 06:19:55 AM.

+ Pass: Change into directory "lab1".

### Part 1: Debugging

+  _1_ / _1_ : Pass: Check that an OCaml file "lab1.ml" has no syntax or type errors.

    OCaml file "lab1.ml" has no syntax or type errors.



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   zero
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   fn 0
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   beginning "abc"
   ```
   matches the pattern `'a'`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   len "abc"
   ```
   matches the pattern `3`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   mult 2 3
   ```
   matches the pattern `6`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   or3 true true false
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   helloworld
   ```
   matches the pattern `"helloworld"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   ending "test" 3
   ```
   matches the pattern `"tes"`.

   




#### Subtotal: _9_ / _9_

### Part 2: Functions

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sumsquares 0
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sumsquares 1
   ```
   matches the pattern `1`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sumsquares 4
   ```
   matches the pattern `30`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sumodds 1
   ```
   matches the pattern `1`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sumodds 4
   ```
   matches the pattern `4`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sumodds 8
   ```
   matches the pattern `16`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   sumf (fun n -> 1) 10
   ```
   matches the pattern `11`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value sumf
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   sumf (fun n -> 2*n) 5
   ```
   matches the pattern `30`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value sumf
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   sumf (fun n -> (n land 1)*n) 8
   ```
   matches the pattern `16`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value sumf
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   countc "acab" 'a'
   ```
   matches the pattern `2`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   countc "birdofprey" 'z'
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   countc "zzzzz" 'z'
   ```
   matches the pattern `5`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   rightjustify 5 123
   ```
   matches the pattern `"  123"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   rightjustify 1 314
   ```
   matches the pattern `"314"`.

   




#### Subtotal: _11_ / _14_

### Part 3: Vector Functions

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   scale 3. (1., 2.)
   ```
   matches the pattern `(3., 6.)`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   scale 2. (-1.,4.)
   ```
   matches the pattern `(-2.,8.)`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   length (3.,4.)
   ```
   matches the pattern `5.`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   length (5.,12.)
   ```
   matches the pattern `13.`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   vec_add (1.0,2.5) (3.0,-1.0)
   ```
   matches the pattern `(4., 1.5)`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   vec_add (0.0,1.0) (2.0,2.0)
   ```
   matches the pattern `(2., 3.)`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   dot (0.0,2.0) (1.0,3.14)
   ```
   matches the pattern `6.28`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value dot
Hint: Did you mean not?
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   dot (1.0,-1.0) (3.0,4.0)
   ```
   matches the pattern `-1.`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value dot
Hint: Did you mean not?
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   perp (0.,1.) (-1.,0.)
   ```
   matches the pattern `true`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value perp
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   perp (1.,2.) (-1.,1.)
   ```
   matches the pattern `false`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value perp
`


#### Subtotal: _6_ / _10_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

