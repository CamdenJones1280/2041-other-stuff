# Lab 2: Lists, Tail Recursion and Type Errors

*CSci 2041: Advanced Programming Principles, Spring 2022 (Section 1)*

**Due:** Tuesday, February 1 at 11:59pm (CST)

In your local copy of the public 'labs2041' repository, do a `git pull` to grab the files for this week's lab exercises.  Then let's get started practicing writing OCaml programs!

# 1. Some functions on lists

The file `lab2/listfun.ml` contains some syntax to get you started on this problem.  Copy it to an `lab2` directory in your personal repository (remember to `git add` the directory and the file before you commit!) and read on:

### `range`

Students who have coded in python will likely be familiar with the function `range`, which can be used as a way to iterate through a list of integers via the idiom `for i in range(m,n): ...`.  Write the equivalent ocaml function:
```
range : int -> int -> int list
```
that takes two integers as parameters, and returns a list of all integers that are at least its first argument, and less than its second argument, that is:

+ `range 1 10` evaluates to `[1; 2; 3; 4; 5; 6; 7; 8; 9]`
+ `range 2 3` evaluates to `[2]`
+ `range 10 1` evaluates to `[]` (because there are no integers that are greater than or equal to `10` and less than `1`)

### `sum_positive`

The function `sum_positive : int list -> int` should take a list of integers as a parameter and return the sum of all of the positive integers in the list.  Some example evaluations:

+ `sum_positive []` evaluates to `0` because the sum of no integers is `0`.
+ `sum_positive [-1]` evaluates to `0`.
+ `sum_positive [1;-1;17]` evaluates to `18`

### `list_cat`

The function `list_cat : string list -> string` should take as input a list of
strings and produces the concatenation of the strings in the list.  Some example evaluations:

+ `list_cat ["what"; "is"; "this"; "I"; "don't"; "even"]` evaluates to
`"whatisthisIdon'teven"`.  
+ `list_cat []` evaluates to `""`.
+ `list_cat ["short "; "list"]` evaluates to `"short list"`

### `take`

The `functions.ml` file contains a buggy implementation of the function `take :
int -> 'a list -> 'a list`.  The intended behavior is that `take n lst` returns
the first `n` elements of `lst`, or all of `lst` if it has fewer than `n`
elements.  Some example evaluations:

+ `take 1 []` evaluates to `[]`
+ `take 2 [ "a"; "b"; "c" ]` evaluates to `["a"; "b"]`
+ `take 0 [ 1; 2; 3 ]` evaluates to `[]`

Fix the implementation in the file to match this behavior.

### `unzip`

The `unzip` function takes as input a list `lst` of pairs, and returns a pair of
lists `(l1,l2)`: `l1` contains the first element of each pair in `lst` and `l2`
contains the second element of each pair in `lst`. Some example evaluations:

 + `unzip [ ("a",100); ("b",99); ("c",98) ]` should evaluate to `(["a"; "b"; "c"], [100; 99; 98])`
 + `unzip []` should evaluate to `([],[])`
 + `unzip [(true,"T");(false, "F")]` should evalate to `([true; false], ["T"; "F"])`

_**Test cases:**_ Your solution must compile and agree on 12/15 example evaluations given above to get full credit for this question.

# 2. Tail Recursion and nested functions

The file `lab2/tailrec.ml` contains some syntax to get you started on this problem.  Copy it to the `lab2` directory in your personal repository (remember to `git add` the directory and the file before you commit!) and read on:

### `index_sum`

The function `index_sum : int list -> int` takes as input a list `[x1; x2; ...; xN]` and should return the integer `1*x1 + 2*x2 + ... + N * xN` (that is, the `i`th list element is multiplied by `i` in the sum).  Write a tail-recursive implementation of this function that uses a local helper function (which should have three inputs: the current index, the accumulated sum, and the rest of the list).  Some example evaluations:

+ `index_sum [17]` should evaluate to `17`
+ `index_sum [10; 9; 8]` should evaluate to `1*10 + 2*9 + 3*8` = `52`
+ `index_sum [3; 1; 4; 1; 5]` should evaluate to `3*1 + 1*2 + 4*3 + 1*4 + 5*5` = `46`


### `range` again

Most likely your implementation of `range` from part 1 was not tail recursive.  Rework it here to use a tail-recursive helper function so that it uses at most a fixed number of stack frames regardless of the input parameters.

### `list_min`

The function `list_min : 'a list -> 'a -> 'a` takes as input a list `ls` and a "default element" `d` and should return the minimum element in the list `ls`, or `d` if the list is empty.  Write a tail-recursive implementation of this function.  Here are some example evaluations:

+ `list_min [15; 12; 4; 37] 0` should evaluate to `4`
+ `list_min ["abc"] ""` should evaluate to `"abc"`
+ `list_min (range 1 1000000) 0` should evaluate to `1` and not cause a stack overflow.


### `*@` operator
Another way to build lists in python is with the `*` operation: `n*lst` is `n` copies of the list `lst`, so for example `3*[1,2]` is the list `[1,2,1,2,1,2]`.  Let's implement the operator `( *@ ) : int -> 'a list -> 'a list` in OCaml to have the same behavior, and use tail recursion to use a fixed number of stack frames regardless of the input parameters.  Some example evaluations:

+ `3 *@ [1;2]` evaluates to `[1;2;1;2;1;2]`
+ `0 *@ [3.14159; 2.71828]` evaluates to `[]` (the same for any negative number of copies)
+ `17 *@ []` evaluates to `[]`


**Note**: The `@` operator is not tail-recursive; it is implemented exactly as we described the function `append` in class.

### Additional test cases
+ `range 1 1` evaluates to `[]`
+ `range 13 17` evaluates to `[13; 14; 15; 16]`
+ `range 0 10000000` does not fail with `Stack_overflow`
+ `10000000 *@ [1;2]` does not fail with `Stack_overflow`

_**Test Cases:**_ For full credit your solution should pass 10/13 of the example evaluations given above.

# 3. Types and Type Inference

The file `lab2_types.ml` contains four function definitions involving
polymorphic types, however they each contain mistakes that either cause them to have different types than intended or to have a type error.  For each definition, you should identify the problem causing the incorrect type or type error and fix the definition so that the function computes the intended functionality.

### `lastpair`

The function `lastpair : 'a list -> ('a * 'a)` should return the last two elements of a list of arbitrary type, as a pair, e.g.  `lastpair [1;2;3]` should evaluate to `(2,3)` and `lastpair ["a";"b"]` should evaluate to `("a","b")`.  

### `has_any`

The function `has_any : 'a -> 'a list -> bool` should return true if its second argument contains any elements equal to its first argument, e.g. `has_any "a" ["b"; "c"]` should evaluate to `false` and `has_any 1 [1;1]` should evaluate to `true`.

### `lookup`

The function `lookup : 'a -> ('a * 'b) list -> 'b` should take a key `k` and a list of (key,value) pairs and return the first value associated to the input key, so `lookup 2 [(1,"a"); (2,"b")]` should evaluate to `"b"` and `lookup "msp" [("msp",3.0); ("den",2.7); ("ord",2.0)]` should evaluate to `3.0`.

### `revrev`

The function `revrev : 'a list list -> 'a list` should flatten and reverse a list of lists, so `revrev [["a";"b"]; ["c";"d"]]` should evaluate to `["d";"c";"b";"a"]` and `revrev [[9;5;1;4]; [1;3]]` should evaluate to `[3;1;4;1;5;9]`

_**Test Cases:**_   For full credit you should get at least 6/8 points.
