(* Type inference examples.  These functions all have type errors *)

let rec lastpair lst =
  match lst with
  | [] | [_] -> invalid_arg "lastpair"
  | h1::h2::[] -> (h1,h2)
  | (h1::h2) -> lastpair h2

let rec has_any x lst =
  match lst with
  | [] -> false
  | (h::t) -> x=h || has_any x t

let rec lookup key lst =
  match lst with
  | (k,v)::[] -> v
  | (k,v)::t -> if k=key then v else lookup key t

let rec revrev lst =
  let rec inrev acc = function [] -> acc
  | h::t -> inrev [h]::acc t
  in let rec outrev acc = function [] -> acc
  | h::t -> outrev (inrev h)@acc t
in outrev [[]] lst
