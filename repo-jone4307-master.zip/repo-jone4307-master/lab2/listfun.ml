(* listfun.ml - lab 2, CSci 2041, Spring 2022 *)
(* Camden Jones *)


(* Complete these functions on int lists *)

(*range function*)
let rec range (m:int) (n:int) =
if (n-m) = 1 then [m]
else if m >= n then []
else range m (n-1) @ [n-1]


(*sum positive function*)
let rec sum_positive (ls: int list) =
match ls with
| [] -> 0
| h::t -> if h > 0 then h + sum_positive t else 0 + sum_positive t


(*list cat function*)
let rec list_cat (ls : string list) : string = 
match ls with
| s::t -> s ^ (list_cat t)
| [] -> ""


(* Fixed take definition *)
let rec take m lst = match (m,lst) with
| (_,[]) -> []
| (0,_) -> []
| (n,h::t) -> h::(take (n-1) t)

(* Perhaps a little trickier *)
let rec unzip (ls : ('a * 'b) list) : ('a list) * ('b list) = ([],[])
