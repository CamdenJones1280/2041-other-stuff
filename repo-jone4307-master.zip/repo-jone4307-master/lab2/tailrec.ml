(* tailrec.ml - lab 2, CSci 2041, Spring 2022 *)
(* Camden Jones *)


(* Fill in tail-recursive index-sum *)
let rec index_sum ls = 
  let rec indy_sum total curr_index ls =
  match ls with
  | [] -> total
  | h::t -> indy_sum (total + curr_index * h) (curr_index +1) t
in indy_sum 0 1 ls


(* Fill in tail recursive range *)
let rec range m n = 
  let rec range_help ls (m:int) (n:int)  =
  if (n-m) = 1 then (n-1) :: ls
  else if m >= n then []
  else range_help ((n-1) :: ls) m (n-1)
in range_help [] m n
  

(* Fill in tail-recursive list_min *)
let rec list_min lst d = 
  let rec min_help lst d low=
  match lst with
  | [] -> low
  | h::t -> if h <= low then min_help t d h else min_help t d low
in min_help lst d (match lst with | h::t -> h | []-> d)


(* *@ operator *)
let ( *@ ) : int -> 'a list -> 'a list =
  let rec helper acc n l = [] in fun n ls -> helper [] n ls
