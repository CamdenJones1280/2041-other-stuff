## Assessment for Lab 2

Run on February 02, 10:01:26 AM.

+ Pass: Change into directory "lab2".

### Part 1: Some functions on lists

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   range 1 10
   ```
   matches the pattern `[1; 2; 3; 4; 5; 6; 7; 8; 9]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   range 2 3
   ```
   matches the pattern `[2]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   range 10 1
   ```
   matches the pattern `[]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sum_positive []
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sum_positive [-1]
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   sum_positive [1;-1;17]
   ```
   matches the pattern `18`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   list_cat ["what"; "is"; "this"; "I"; "dont"; "even"]
   ```
   matches the pattern `"whatisthisIdonteven"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   list_cat []
   ```
   matches the pattern `""`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   list_cat ["short "; "list"]
   ```
   matches the pattern `"short list"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take 1 []
   ```
   matches the pattern `[]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take 2 [ "a"; "b"; "c" ]
   ```
   matches the pattern `["a"; "b"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   take 0 [ 1; 2; 3 ]
   ```
   matches the pattern `[]`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   unzip [ ("a",100); ("b",99); ("c",98) ]
   ```
   matches the pattern `(["a"; "b"; "c"], [100; 99; 98])`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string list * int list = ([], [])
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   unzip []
   ```
   matches the pattern `([], [])`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   unzip [(true,"T");(false, "F")]
   ```
   matches the pattern `([true; false], ["T"; "F"])`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : bool list * string list = ([], [])
`


#### Subtotal: _13_ / _15_

### Part 2: Tail Recursion and nested functions

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   index_sum [17]
   ```
   matches the pattern `17`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   index_sum [10; 9; 8]
   ```
   matches the pattern `52`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   index_sum [3; 1; 4; 1; 5]
   ```
   matches the pattern `46`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   range 1 1
   ```
   matches the pattern `[]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   range 13 17
   ```
   matches the pattern `[13; 14; 15; 16]`.

   




+  _1_ / _1_ : Pass: Check that evaluating range 0 1000000 in file tailrec.ml does not result in a stack overflow.

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   list_min [15;12;4;37] 0
   ```
   matches the pattern `4`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   list_min ["abc"] ""
   ```
   matches the pattern `"abc"`.

   




+  _1_ / _1_ : Pass: Check that evaluating list_min (range 1 1000000) 0 in file tailrec.ml does not result in a stack overflow.

+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   3 *@ [1;2]
   ```
   matches the pattern `[1;2;1;2;1;2]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : int list = []
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   0 *@ [3.14159; 2.71828]
   ```
   matches the pattern `[]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   17 *@ []
   ```
   matches the pattern `[]`.

   




+  _1_ / _1_ : Pass: Check that evaluating 1000000 *@ [1;2] in file tailrec.ml does not result in a stack overflow.

#### Subtotal: _12_ / _13_

### Part 3: Types and Type Inference

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lastpair [1;2;3]
   ```
   matches the pattern `(2,3)`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lastpair ["a";"b"]
   ```
   matches the pattern `("a","b")`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   has_any "a" ["b";"c"]
   ```
   matches the pattern `false`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   has_any 1 [1;1]
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lookup 2 [(1,"a"); (2,"b")]
   ```
   matches the pattern `"b"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   lookup "msp" [("msp",3.0); ("den",2.7); ("ord",2.0)]
   ```
   matches the pattern `3.0`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   revrev [["a";"b"]; ["c";"d"]]
   ```
   matches the pattern `["d";"c";"b";"a"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value revrev
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   revrev [[9;5;1;4]; [1;3]]
   ```
   matches the pattern `[3;1;4;1;5;9]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value revrev
`


#### Subtotal: _6_ / _8_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

