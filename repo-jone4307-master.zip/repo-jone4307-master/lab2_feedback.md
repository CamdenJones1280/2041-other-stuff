### Feedback for Lab 2

Run on January 31, 18:06:11 PM.

+ Pass: Change into directory "lab2".

+ Pass: Check that file "listfun.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   range 1 10
   ```
   matches the pattern `[1; 2; 3; 4; 5; 6; 7; 8; 9]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   range 2 3
   ```
   matches the pattern `[2]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   range 10 1
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   sum_positive []
   ```
   matches the pattern `0`.

   




+ Pass: 
Check that the result of evaluating
   ```
   sum_positive [-1]
   ```
   matches the pattern `0`.

   




+ Pass: 
Check that the result of evaluating
   ```
   sum_positive [1;-1;17]
   ```
   matches the pattern `18`.

   




+ Pass: 
Check that the result of evaluating
   ```
   list_cat ["what"; "is"; "this"; "I"; "dont"; "even"]
   ```
   matches the pattern `"whatisthisIdonteven"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   list_cat []
   ```
   matches the pattern `""`.

   




+ Pass: 
Check that the result of evaluating
   ```
   list_cat ["short "; "list"]
   ```
   matches the pattern `"short list"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   take 1 []
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   take 2 [ "a"; "b"; "c" ]
   ```
   matches the pattern `["a"; "b"]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   take 0 [ 1; 2; 3 ]
   ```
   matches the pattern `[]`.

   




+ Fail: 
Check that the result of evaluating
   ```
   unzip [ ("a",100); ("b",99); ("c",98) ]
   ```
   matches the pattern `(["a"; "b"; "c"], [100; 99; 98])`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string list * int list = ([], [])
`


+ Pass: 
Check that the result of evaluating
   ```
   unzip []
   ```
   matches the pattern `([], [])`.

   




+ Fail: 
Check that the result of evaluating
   ```
   unzip [(true,"T");(false, "F")]
   ```
   matches the pattern `([true; false], ["T"; "F"])`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : bool list * string list = ([], [])
`


+ Pass: Check that file "tailrec.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   index_sum [17]
   ```
   matches the pattern `17`.

   




+ Pass: 
Check that the result of evaluating
   ```
   index_sum [10; 9; 8]
   ```
   matches the pattern `52`.

   




+ Pass: 
Check that the result of evaluating
   ```
   index_sum [3; 1; 4; 1; 5]
   ```
   matches the pattern `46`.

   




+ Pass: 
Check that the result of evaluating
   ```
   range 1 1
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   range 13 17
   ```
   matches the pattern `[13; 14; 15; 16]`.

   




+ Pass: Check that evaluating range 0 1000000 in file tailrec.ml does not result in a stack overflow.

+ Pass: 
Check that the result of evaluating
   ```
   list_min [15;12;4;37] 0
   ```
   matches the pattern `4`.

   




+ Pass: 
Check that the result of evaluating
   ```
   list_min ["abc"] ""
   ```
   matches the pattern `"abc"`.

   




+ Pass: Check that evaluating list_min (range 1 1000000) 0 in file tailrec.ml does not result in a stack overflow.

+ Fail: 
Check that the result of evaluating
   ```
   3 *@ [1;2]
   ```
   matches the pattern `[1;2;1;2;1;2]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : int list = []
`


+ Pass: 
Check that the result of evaluating
   ```
   0 *@ [3.14159; 2.71828]
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   17 *@ []
   ```
   matches the pattern `[]`.

   




+ Pass: Check that evaluating 1000000 *@ [1;2] in file tailrec.ml does not result in a stack overflow.

+ Pass: Check that file "lab2_types.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   lastpair [1;2;3]
   ```
   matches the pattern `(2,3)`.

   




+ Pass: 
Check that the result of evaluating
   ```
   lastpair ["a";"b"]
   ```
   matches the pattern `("a","b")`.

   




+ Pass: 
Check that the result of evaluating
   ```
   has_any "a" ["b";"c"]
   ```
   matches the pattern `false`.

   




+ Pass: 
Check that the result of evaluating
   ```
   has_any 1 [1;1]
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   lookup 2 [(1,"a"); (2,"b")]
   ```
   matches the pattern `"b"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   lookup "msp" [("msp",3.0); ("den",2.7); ("ord",2.0)]
   ```
   matches the pattern `3.0`.

   




+ Fail: 
Check that the result of evaluating
   ```
   revrev [["a";"b"]; ["c";"d"]]
   ```
   matches the pattern `["d";"c";"b";"a"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value revrev
`


+ Fail: 
Check that the result of evaluating
   ```
   revrev [[9;5;1;4]; [1;3]]
   ```
   matches the pattern `[3;1;4;1;5;9]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value revrev
`


