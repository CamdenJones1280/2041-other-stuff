(* Minnesota Whist *)

type card_suit = Hearts | Clubs| Spades | Diamonds 
type card_value = Two | Three | Four | Five | Six | Seven | Eight | Nine | Ten | Jack | Queen | King | Ace
type card = { value : card_value ; suit : card_suit }

(* Just generally a lot of missing code below... *)
let string_of_value v = match v with
| Ace -> "A"
| King -> "K"
| Queen -> "Q"
| Jack -> "J"
| Ten -> "10"
| Nine -> "9"
| Eight -> "8"
| Seven -> "7"
| Six -> "6"
| Five -> "5"
| Four -> "4"
| Three -> "3"
| Two -> "2"

let string_of_suit s = match s with
| Hearts -> "H"
| Clubs -> "C"
| Spades -> "S"
| Diamonds -> "D"

let string_of_card { value; suit } = (string_of_value value) ^ (string_of_suit suit)

let suit_of_char c = match c with
| 'H' -> Hearts
| 'C' -> Clubs
| 'S' -> Spades
| 'D' -> Diamonds
| _ -> invalid_arg "not a suit of cards!"

let value_of_string c = match c with
| "2" -> Two
| "3" -> Three
| "4" -> Four
| "5" -> Five
| "6" -> Six
| "7" -> Seven
| "8" -> Eight
| "9" -> Nine
| "10" -> Ten
| "J" -> Jack
| "Q" -> Queen
| "K" -> King
| "A" -> Ace
| _ -> invalid_arg "not a card value!"

let card_of_string s = let l = (String.length s) - 1 in
  { value = value_of_string (String.sub s 0 l) ; suit = suit_of_char s.[l] }

let trick_winner cards = match cards with
| [] -> invalid_arg "empty trick"
| lead::t::rest -> if t.suit <> lead.suit then lead else if t.value > lead.value then t else lead