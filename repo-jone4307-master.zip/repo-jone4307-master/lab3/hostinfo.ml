(* hostinfo, the "name" of a computer connected to the Internet *)
type hostinfo = IP of int*int*int*int | DNSName of string

(* Here's where your definition of tld goes: *)
let tld (addr : hostinfo) : string option = 
match (addr : hostinfo) with
| (IP _) -> None
| (DNSName nm)-> let index = String.rindex nm '.' in Some (String.sub nm (index+1) 3)

