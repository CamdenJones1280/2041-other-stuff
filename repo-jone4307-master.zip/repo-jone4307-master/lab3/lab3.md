# Lab 3: Program-defined types in OCaml

*CSci 2041: Advanced Programming Principles, Spring 2022 (Section 1)*

**Due:** Tuesday, February 8 at 11:59pm (CST)

In your local copy of the public 'labs2041' repository, do a `git pull` to grab the files for this week's lab exercises.  Then let's get started practicing with type declarations!

# 1. Records and enumerated unions: Card Games

The file `lab/cards.ml` contains some syntax to help get started on this problem.  Copy it to an `lab3` directory in your personal repository to get started with them.

## Card Games

A "standard" card deck consists of 52 cards, each suit (Hearts, Clubs, Spades, Diamonds) having thirteen cards (2 through 10, Jack, Queen, King, Ace).  The file `cards.ml` contains incomplete definitions for three types: `card_suit`, `card_value`, and `card` (a record with suit and value fields.)  It also has incomplete definitions for functions to convert string representations of cards, like `"KD"` for Jack of Diamonds, into values of type `card`. (We're too lazy to look up how to represent a diamond, heart, club, or spade as a unicode character in OCaml.  If you want, you can add `unicode_string_of_card` and `card_of_unicode_string` functions to handle these fancier string representations.)

### `card_suit`, `card_value`, `string_of_card`, `card_of_string`

Complete the definitions of the `card_suit` and `card_value` types, along with the `card_of_string` and `string_of_card` functions.  Your definitions should allow comparisons between values of type `card_value` so that, for example, `Two < Five` and `Three < Queen` evaluate to true.  Some sample evaluations:

+ `let s : card_suit = Spades` should compile without errors

+ `let v : card_value = Jack` should compile without errors

+ `let c4c = { value = Four; suit = Clubs }` should compile without errors

+ `let cqd = { value = Queen; suit = Diamonds }` should compile without errors

+ `card_of_string "10D"` should evaluate to the record `{ value = Ten; suit = Diamonds }`

+ `string_of_card (card_of_string "9H")` should evaluate to `"9H"`


### `trick_winner`

Many card games involve play in "tricks" (eg. Spades, Hearts, Bridge, Whist), in which a player leads with a card, and other players also lay out cards, of the same suit if possible.  Once all players have played cards, the highest card of the same suit as the lead card "wins" or "takes" the "trick."  (and typically becomes the leader for the next trick.)  In `cards.ml` there is a prototype for the function `trick_winner : card list -> card` which should return the value of the winning `card` from a list of `card` values, assuming the cards were played in the order given.  (Assuming there are no "trump" cards, and Aces are "high".)  Fill in the definition for this function.  Some sample evaluations:

+ `trick_winner [ {value = Two; suit = Hearts}; {value = King; suit = Spades } ]` should evaluate to `{ value = Two; suit = Hearts }` because the lead suit was Hearts.

+ `trick_winner [ {value = Two; suit = Hearts}; {value = King; suit = Hearts } ]` should evaluate to `{ value = King; suit = Hearts }` because the King had the same suit as the lead card.

+ `trick_winner []` should raise an exception with `invalid_arg "empty trick"` because there can't be a winner in a trick with no cards.


_**Test cases:**_ Your solution must compile and agree on 8/9 example evaluations given above to get full credit for this question.

# 2. Disjoint unions

### TLD of hostinfo

In lecture, we defined a type `hostinfo` that is either a 4-byte "IP
address" (like `(134,84,159,182)`) or a string-valued "DNS name" (like
`"www.myu.umn.edu"`):

```
type hostinfo = IP of int * int * int * int | DNSName of string
```
We've conveniently placed this type definition in the file
`lab3/hostinfo.ml`.

An important property of a DNS name is the _top level domain_ - the
string after the last `'.'` character. For example the top-level
domain (or TLD) of "www.myu.umn.edu" is "edu", the TLD of
"www.google.com" is "com", and the TLD of "cs2041.org" is "org".
In `hostinfo.ml`, add the OCaml definition for the function `tld : hostinfo -> string
option`, which returns the TLD of a hostinfo value that is a DNS
name, and `None` if its argument is an IP address.   Some example
evaluations:

+ `tld (IP (8,8,8,8))` evaluates to `None` because its argument is an
IP value.
+ `tld (DNSName "cnn.com")` evaluates to `Some "com"`
+ `tld (DNSName "comcast.net")` evaluates to `Some "net"`

Hint: you might find the functions `String.sub` and `String.rindex` in the
[`String` module](http://caml.inria.fr/pub/docs/manual-ocaml/libref/String.html)
to be useful here.

### Number type

Add a file named `number.ml` to your lab3 directory, where you'll write the answers for this question.  

#### Declare a `number` type and some constants

The first step of this problem is to declare a new union type,
`number`, that should have two value constructors: one, `Z` that takes an
`int` as its value and one, `R` that takes a `float` argument. Make sure that your
type declaration compiles correctly.  Some test cases:

+ `let n : number = Z 3` should compile without errors

+ `let e : number = R 2.718` should compile without errors.

### `number` conversions

Now that we have succesfully declared the type, let's add three
conversion functions:

+ `to_int : number -> int option` should take argument `n : number`,
  and if `n` holds an integer `i` should evaluate to `Some i`,
  otherwise it should evaluate to `None`.

+ `to_float : number -> float option` should take argument `n :
  number` and if `n` holds a float `x`, should evaluate to `Some x`,
  otherwise it should evaluate to `None`.

+ `float_of_number : number -> float` should _coerce_ the value it
  holds to a floating point value.  Recall that the function
  `float_of_int : int -> float` can be used to coerce an `int` to a
  `float` in OCaml.

Some test cases:

+ `to_int (Z 0)` should evaluate to `Some 0`
+ `to_int (R 3.14159)` should evaluate to `None`
+ `to_float (Z 1)` should evaluate to `None`
+ `to_float (R 6.02e+23)` should evaluate to `Some 6.02e+23`
+ `float_of_number (Z 17)` should evaluate to `17.`
+ `float_of_number (R 0.01)` should evaluate to `0.01`

#### `number` arithmetic

Define the `number` operator `+?` with type `number ->
number -> number` that performs addition on
`number`s:  if both arguments hold  `int` values then the
result should also hold an `int`, while if either argument holds a
`float` value the result also holds a `float` value.

Some example evaluations:

+ `(Z 3) +? (R 0.)` should evaluate to `(R 3.)`
+ `(Z 42) +? (Z 17)` should evaluate to `(Z 59)`
+ `(R 0.) +? (R (-1.))` should evaluate to `(R -1.)`

_**Test Cases:**_ For full credit your solution should pass 9/14 of the example evaluations given above.

# 3. Recursive Types

### Binary Search trees

Binary trees are a fundamental data structure in computer science, which you
will have seen in CSci 1933 or its equivalent.  A _binary search tree_ is an
extension of a binary tree that allows for efficient search and insertion of
elements, by enforcing the requirement that the value stored at each internal
node is greater than or equal to all elements in its left subtree, and less than
or equal to all elements in its right subtree.  You'll find the type definition
and function definitions for `insert` and `search` in the file `lab3/btree.ml`,
and you should add your code for this problem to the same program.

+ Complete the function `tree_min : 'a btree -> 'a option` that finds the
smallest element in a binary tree (BST or not).  Example evaluations: `tree_min
Empty` should evaluate to `None`; `tree_min t3` should evaluate to `Some 3`

+ Complete the function `tree_max : 'a btree -> 'a option` which finds the
largest element in a binary tree (BST or not). Example evaluations: `tree_max
Empty` should evalute to `None`; `tree_max t5` should evaluate to `Some 12`.

+ Now fix the function `is_bstree : 'a bstree -> bool` that checks that its
argument satisfies the binary search tree condition.  Example evaluations:
`is_bstree Empty` should evaluate to `true`, `is_bstree (Node("0",Empty,Leaf "1"))`
should evaluate to `true`, `is_bstree (Node("0",Leaf "1",Empty))` should evaluate to
`false`, and `is_bstree t3` should evaluate to `false`.

### An RPN Arithmetic calculator

The file that we are about to inspect relies on the `Str` module. When
using ocamlbuild, this dependency will be automatically detected
and this module will be loaded. However, `utop` will not do this and we must
instruct `utop` to load this library manually. We will do this by editing a file
**at the root of your home directory(e.g., /home/user1234/)** called
`.ocamlinit`. This file is automatically loaded by `utop` on startup. Open this
file in an editor and add a line containing `#load "str.cma";;`.
Compiled ocaml modules have the extension `cma` and there are some number
of default locations that ocaml will look for compiled ocaml modules. So,
adding `#load "str.cma";;` to `~/.ocamlinit` (`~` is a kind of macro that
means "my home directory") instructs `utop` to look for the `Str` module
and load it on start up.

Let's look more at using inductively defined types to represent expressions
The file `lab3/arithExp.ml` contains type declarations related to
representing airthmetic expressions over floating point numbers, and
parsing their representation from *Reverse Polish Notation* strings.

>_Aside: Reverse Polish what now?_
>
>An expression in RPN uses postfix operators, so "a b +" is the sum of
>"a" and "b", "a b *" is the product, and so on.  Values in the
>expression can be thought of as accumulating on a stack, and each
>arithmetic operation pops its argument(s) from the stack and pushes the result.
>Well-formed expressions result in exactly one value.  This has the
>interesting property that parentheses are never needed to express the
>order of operations.

The function `token_list` converts a string into a list of
`arithToken`s, and will result in a run-time error if the string
contains anything that is not `"+"`, `"*"`, `"-"` (for unary negation),
or a floating point number.  The function `rpnParse` interprets a list
of tokens as an RPN expression and attempts to build an arithExpr that
corresponds to this expression: notice that the nested `parser`
function uses an `arithExpr list` to keep track of the expression
stack and uses matching to "pop" values off the stack.  Finally, the
function `arithExpEval` evaluates an `arithExpr` and returns the
floating point value.  So to evaluate a string `s` as an RPN arithmetic
expression, we would call `arithExpEval (rpnParse (token_list s))`.

### Testing it out

At the bottom of the file, add declarations for two `arithExpr`
values, `e1` and `e2`.  The first should correspond to the (usual, infix) expression
`1.414 + (3.14 * 2)` and the second can correspond to an expression of
your choosing.  Then add two strings that represent these expressions
in RPN.  You can `#use` the file in `utop` and check whether the composition
`rpnParse` and `token_list` computes the same `arithExpr` values from
these strings.

### Extending the code

Now let's extend the code to add division to the calculator, so for
example the string `"1 2 /"` will evaluate to `0.5`.  We'll need to:

+ Add a new null-ary value constructor `DIV` to the type `arithToken` to
  represent the division operator.

+ Extend the `tokens` helper function in `token_list` to recognize the
  division operator in a string.

+ Extend the `arithExpr` type with a new value constructor, `DivExpr` that holds
  a pair of `arithExpr`s.

+ Extend the `parser` helper function in `rpnParse` to handle the
  division token.  (This will look a lot like the cases for `PLUS` and
  `TIMES`, but needs a little care because of the order of elements on
  the stack...)

+ Extend the `arithExpEval` function to handle values constructed
  using the new variant for division expressions.

The gitbot will check that:

+ `e1` is correct
+ `e2` has type ArithExpr
+ `DIV` is a valid constructor for `arithToken`
+ `token_list "/"` evaluates to `[DIV]`
+ `DivExpr` is a valid two-argument constructor for `arithExpr`
+ `rpnParse [CONST 1.; CONST 2.; DIV]` evaluates to `DivExpr (ConstExpr 1., ConstExpr 2.)`
+ `arithExpEval (DivExpr (ConstExpr 1., ConstExpr 2.))` evaluates to `0.5`
+ `arithExpEval (rpnParse (token_list "3 4 / 8 *"))` evaluates to `6.0`


_**Test Cases:**_  To get full credit for problem 3 your solution should pass at least 9/16 of the example evaluations.
