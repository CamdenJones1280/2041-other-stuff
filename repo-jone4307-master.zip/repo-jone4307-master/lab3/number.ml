type number = Z of int | R of float

let to_int n =
match n with 
| Z i -> Some i
| R x-> None

let to_float n =
match n with 
| Z i -> None
| R x-> Some x

let float_of_number n =
match n with 
| Z i -> float_of_int i
| R x-> x