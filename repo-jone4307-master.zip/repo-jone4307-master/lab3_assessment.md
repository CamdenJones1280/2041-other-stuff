## Assessment for Lab 3

Run on February 09, 09:47:29 AM.

+ Pass: Change into directory "lab3".

### Part 1: Card Games

+  _1_ / _1_ : Pass: Check that expression `Spades` following file cards.ml has type `card_suit`

+  _1_ / _1_ : Pass: Check that expression `Jack` following file cards.ml has type `card_value`

+  _1_ / _1_ : Pass: Check that expression `{ value = Four; suit = Clubs }` following file cards.ml has type `card`

+  _1_ / _1_ : Pass: Check that expression `{ value = Queen; suit = Diamonds }` following file cards.ml has type `card`

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   card_of_string "10D"
   ```
   matches the pattern `{ value = Ten; suit = Diamonds }`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   string_of_card (card_of_string "9H")
   ```
   matches the pattern `"9H"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   trick_winner [ {value = Two; suit = Hearts}; {value = King; suit = Spades } ]
   ```
   matches the pattern `{ value = Two; suit = Hearts }`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   trick_winner [ { value = Two; suit = Hearts}; {value = King; suit = Hearts } ]
   ```
   matches the pattern `{ value = King; suit = Hearts }`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   try (Some (trick_winner [ ])) with Invalid_argument _ -> None
   ```
   matches the pattern `None`.

   




#### Subtotal: _9_ / _9_

### Part 2: Disjoint Unions

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   tld (IP (8,8,8,8))
   ```
   matches the pattern `None`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   tld (DNSName "cnn.com")
   ```
   matches the pattern `Some "com"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   tld (DNSName "comcast.net")
   ```
   matches the pattern `Some "net"`.

   




+  _1_ / _1_ : Pass: Check that expression `(Z 3)` following file number.ml has type `number`

+  _1_ / _1_ : Pass: Check that expression `(R 2.718)` following file number.ml has type `number`

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   to_int (Z 0)
   ```
   matches the pattern `Some 0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   to_int (R 3.14159)
   ```
   matches the pattern `None`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   to_float (Z 1)
   ```
   matches the pattern `None`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   to_float (R 6.02e+23)
   ```
   matches the pattern `Some 6.02e+23`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   float_of_number (Z 17)
   ```
   matches the pattern `17.`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   float_of_number (R 0.01)
   ```
   matches the pattern `0.01`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   (Z 3) +? (R 0.)
   ```
   matches the pattern `(R 3.)`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value +?
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   (Z 42) +? (Z 17)
   ```
   matches the pattern `(Z 59)`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value +?
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   (R 0.) +? (R (-1.))
   ```
   matches the pattern `(R (-1.))`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value +?
`


#### Subtotal: _11_ / _14_

### Part 3: Recursive Types

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   tree_min Empty
   ```
   matches the pattern `None`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   tree_min t3
   ```
   matches the pattern `Some 3`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: This expression has type int btree
       but an expression was expected of type 'a option btree
       Type int is not compatible with type 'a option 

```



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   tree_max Empty
   ```
   matches the pattern `None`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   tree_max t5
   ```
   matches the pattern `Some 12`.

   


   Test failed. The following errors were reported:
` ;;
Exception: Match_failure ("btree.ml", 44, 21).
`

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   is_bstree Empty
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   is_bstree (Node("0",Empty,Leaf "1"))
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   is_bstree (Node("0",Leaf "1",Empty))
   ```
   matches the pattern `false`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   is_bstree t3
   ```
   matches the pattern `false`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : bool = true
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   e1
   ```
   matches the pattern `AddExpr (ConstExpr 1.414, MultExpr (ConstExpr 3.14, ConstExpr 2.))`.

   




+  _1_ / _1_ : Pass: Check that expression `e2` following file arithExp.ml has type `arithExpr`

+  _1_ / _1_ : Pass: Check that expression `DIV` following file arithExp.ml has type `arithToken`

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   token_list "/"
   ```
   matches the pattern `[DIV]`.

   




+  _1_ / _1_ : Pass: Check that expression `DivExpr (ConstExpr 1., ConstExpr 1.)` following file arithExp.ml has type `arithExpr`

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   rpnParse [CONST 1.; CONST 2.; DIV]
   ```
   matches the pattern `DivExpr (ConstExpr 1., ConstExpr 2.)`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   arithExpEval (DivExpr (ConstExpr 1., ConstExpr 2.))
   ```
   matches the pattern `0.5`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   arithExpEval (rpnParse (token_list "3 4 / 8 *"))
   ```
   matches the pattern `6.0`.

   




#### Subtotal: _13_ / _16_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

