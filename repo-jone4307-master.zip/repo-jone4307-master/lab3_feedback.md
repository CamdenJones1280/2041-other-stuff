### Feedback for Lab 3

Run on February 07, 23:19:56 PM.

+ Pass: Change into directory "lab3".

+ Pass: Check that file "cards.ml" exists.

+ Pass: Check that expression `Spades` following file cards.ml has type `card_suit`

+ Pass: Check that expression `Jack` following file cards.ml has type `card_value`

+ Pass: Check that expression `{ value = Four; suit = Clubs }` following file cards.ml has type `card`

+ Pass: Check that expression `{ value = Queen; suit = Diamonds }` following file cards.ml has type `card`

+ Pass: 
Check that the result of evaluating
   ```
   card_of_string "10D"
   ```
   matches the pattern `{ value = Ten; suit = Diamonds }`.

   




+ Pass: 
Check that the result of evaluating
   ```
   string_of_card (card_of_string "9H")
   ```
   matches the pattern `"9H"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   trick_winner [ {value = Two; suit = Hearts}; {value = King; suit = Spades } ]
   ```
   matches the pattern `{ value = Two; suit = Hearts }`.

   




+ Pass: 
Check that the result of evaluating
   ```
   trick_winner [ { value = Two; suit = Hearts}; {value = King; suit = Hearts } ]
   ```
   matches the pattern `{ value = King; suit = Hearts }`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try (Some (trick_winner [ ])) with Invalid_argument _ -> None
   ```
   matches the pattern `None`.

   




+ Pass: Check that file "hostinfo.ml" exists.

+ Pass: Check that file "number.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   tld (IP (8,8,8,8))
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   tld (DNSName "cnn.com")
   ```
   matches the pattern `Some "com"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   tld (DNSName "comcast.net")
   ```
   matches the pattern `Some "net"`.

   




+ Pass: Check that expression `(Z 3)` following file number.ml has type `number`

+ Pass: Check that expression `(R 2.718)` following file number.ml has type `number`

+ Pass: 
Check that the result of evaluating
   ```
   to_int (Z 0)
   ```
   matches the pattern `Some 0`.

   




+ Pass: 
Check that the result of evaluating
   ```
   to_int (R 3.14159)
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   to_float (Z 1)
   ```
   matches the pattern `None`.

   




+ Pass: 
Check that the result of evaluating
   ```
   to_float (R 6.02e+23)
   ```
   matches the pattern `Some 6.02e+23`.

   




+ Pass: 
Check that the result of evaluating
   ```
   float_of_number (Z 17)
   ```
   matches the pattern `17.`.

   




+ Pass: 
Check that the result of evaluating
   ```
   float_of_number (R 0.01)
   ```
   matches the pattern `0.01`.

   




+ Fail: 
Check that the result of evaluating
   ```
   (Z 3) +? (R 0.)
   ```
   matches the pattern `(R 3.)`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value +?
`


+ Fail: 
Check that the result of evaluating
   ```
   (Z 42) +? (Z 17)
   ```
   matches the pattern `(Z 59)`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value +?
`


+ Fail: 
Check that the result of evaluating
   ```
   (R 0.) +? (R (-1.))
   ```
   matches the pattern `(R (-1.))`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value +?
`


+ Pass: Check that file "btree.ml" exists.

+ Pass: Check that file "arithExp.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   tree_min Empty
   ```
   matches the pattern `None`.

   




+ Fail: 
Check that the result of evaluating
   ```
   tree_min t3
   ```
   matches the pattern `Some 3`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: This expression has type int btree
       but an expression was expected of type 'a option btree
       Type int is not compatible with type 'a option 

```



+ Pass: 
Check that the result of evaluating
   ```
   tree_max Empty
   ```
   matches the pattern `None`.

   




+ Fail: 
Check that the result of evaluating
   ```
   tree_max t5
   ```
   matches the pattern `Some 12`.

   


   Test failed. The following errors were reported:
` ;;
Exception: Match_failure ("btree.ml", 44, 21).
`

+ Pass: 
Check that the result of evaluating
   ```
   is_bstree Empty
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   is_bstree (Node("0",Empty,Leaf "1"))
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   is_bstree (Node("0",Leaf "1",Empty))
   ```
   matches the pattern `false`.

   




+ Fail: 
Check that the result of evaluating
   ```
   is_bstree t3
   ```
   matches the pattern `false`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : bool = true
`


+ Pass: 
Check that the result of evaluating
   ```
   e1
   ```
   matches the pattern `AddExpr (ConstExpr 1.414, MultExpr (ConstExpr 3.14, ConstExpr 2.))`.

   




+ Pass: Check that expression `e2` following file arithExp.ml has type `arithExpr`

+ Pass: Check that expression `DIV` following file arithExp.ml has type `arithToken`

+ Pass: 
Check that the result of evaluating
   ```
   token_list "/"
   ```
   matches the pattern `[DIV]`.

   




+ Pass: Check that expression `DivExpr (ConstExpr 1., ConstExpr 1.)` following file arithExp.ml has type `arithExpr`

+ Pass: 
Check that the result of evaluating
   ```
   rpnParse [CONST 1.; CONST 2.; DIV]
   ```
   matches the pattern `DivExpr (ConstExpr 1., ConstExpr 2.)`.

   




+ Pass: 
Check that the result of evaluating
   ```
   arithExpEval (DivExpr (ConstExpr 1., ConstExpr 2.))
   ```
   matches the pattern `0.5`.

   




+ Pass: 
Check that the result of evaluating
   ```
   arithExpEval (rpnParse (token_list "3 4 / 8 *"))
   ```
   matches the pattern `6.0`.

   




