(* funset.ml -- function representation of sets *)

(* an 'a set returns true if (and only if) an element belongs to it *)
type 'a set = 'a -> bool

(* no element belongs to the empty set *)
let empty : 'a set = fun _ -> false

(* membership testing is straightforward *)
let mem x (s: 'a set) = s x

(* adding an element: test for x, otherwise return what s says *)
let add x (s: 'a set) : 'a set = fun y -> (y=x) || (s y)

let union (s1: 'a set) (s2: 'a set) : 'a set = fun r -> s1 r || s2 r

let intersect (s1: 'a set) (s2: 'a set) : 'a set = fun r -> s1 r && s2 r

let rem x (s: 'a set): 'a set = fun r -> (r<>x) && (s r)


