let rec drop_until x ls =
match ls with 
| [] -> []
| h::t -> if (x h) then h::(drop_until x t) else (drop_until x t)

let rec take_while x ls =
match ls with 
| [] -> []
| h::t -> if (x h) then h::(take_while x t) else (take_while x [])

let rec take_until x ls =
match ls with 
| [] -> []
| h::t -> if (x h) then (take_until x []) else h::(take_until x t) 