# Lab Exercise 4: Higher-Order Functions

*CSci 2041: Advanced Programming Principles, Spring 2022 (Section 1)*

**Due:** Tuesday, February 15 at 11:59pm (CST)

In your local copy of the public `labs2041` repository, do a `git pull` to grab the files for this week's lab exercises.  Then let's get started practicing with type declarations!

# 1. Functions and arguments

Create a file name `hof.ml` in the `lab4` directory to hold your solutions to this problem.

### `drop_until`

Provide a definition for the function `drop_until : ('a -> bool) -> ('a list) -> ('a list)` which drops elements from the beginning of a list that do not make its first argument true.  Some example evaluations:

+ `drop_until (fun _ -> true) []` should evaluate to `[]`.

+ `drop_until (fun _ -> true) [1]` should evaluate to `[1]`

+ `drop_until (fun s -> s.[0]='a') ["boring"; "as"; "always"]` should evaluate to `["as"; "always"]`

### `take_while`

Provide a definition for the function `take_while : ('a -> bool) -> 'a list -> 'a list` that returns the prefix list of its second argument such that all elements satisfy its first argument.  Some example evaluations:

+ `take_while (fun _ -> true) [1; 2; 3]` should evaluate to `[1; 2; 3]`.

+ `take_while ((=) "a") ["a"; "a"; "b"; "a"]` should evaluate to `["a"; "a"]`.

+ `take_while (fun _ -> false) ["say"; "anything"]` should evaluate to `[]`

### `take_until`

Provide a definition for the function `take_while : ('a -> bool) -> 'a list -> 'a list` that returns the prefix list of its second argument such that all elements do not satisfy its first argument.  Some example evaluations:

+ `take_until (fun _ -> false) [1; 2; 3]` should evaluate to `[1; 2; 3]`.

+ `take_until ((<>) "a") ["a"; "a"; "b"; "a"]` should evaluate to `["a"; "a"]`.

+ `take_until (fun _ -> true) ["say"; "anything"]` should evaluate to `[]`

#### Test cases

Your solution must compile and agree on 6/9 example evaluations given above to get full credit for this question.

# 2. Implementing sets as functions

In Video 4.2, we discussed implementing sets of elements as lists.  This problem considers an alternative implementation:

```
type 'a set = 'a -> bool
```

In this implementation, **a set is a function that returns `true` if its argument belongs to the set, and `false` otherwise**, so we would implement `mem` as `let mem x s = (s x)`, `empty` as `let empty _ = false`, and `add` as `let add x s = fun y -> (y=x) || (s y)`.  These definitions appear in `lab4/funset.ml`; copy it to the `lab4` directory in your personal repo and add your solutions to the following problems.

### `union`

Add a definition for the function `union : 'a set -> 'a set -> 'a set`, where `x` is in `union s1 s2` if `x` is in `s1` or `x` is in s2.  Some example evaluations:

+ `mem 3 (union empty empty)` should evaluate to `false`

+ `mem 3 (union (add 3 empty) (add 5 empty))` should evaluate to `true`

### `intersect`

Add a definition for the function `intersect : 'a set -> 'a set -> 'a set` so that `x` is in `intersect s1 s2` if and only if `x` is in `s1` and `x` is in `s2`.  Some example evaluations:

+ `mem 0 (intersect empty (add 0 empty))` should evaluate to `false`, since `0` is not an element of the empty set.

+ `let s = (add 0 empty) in mem 0 (intersect s (add 1 s))` should evaluate to `true`.

### `rem`

Add a definition for the function `rem : 'a -> 'a set -> 'a set`, which "removes" an element from a set: the set created by `rem x s` should have the property that `x` is not an element of `rem x s`, but any other element is an element of `rem x s` if and only if it is an element of `s`.  Some example evaluations:

+ `mem 0 (rem 0 (add 0 empty))` should evaluate to `false`

+ `mem "a" (rem "b" (add "a" empty))` should evaluate to `true`

### `range`

One advantage of the functional representation of sets is that we can represent very large sets efficiently.  Write an implementation for the function `range : 'a  -> 'a -> 'a set`, that returns a set of all the elements that are at least its first argument and at most its second argument.  Some example evaluations:

+ `mem 4 (range 4 max_int)` should evaluate to `true`

+ `mem 3 (range 4 max_int)` should evaluate to `false`

+ `mem 0.5 (range 0. 1.)` should evaluate to `true`

+ `mem 2. (range 0. 1.)` should evaluate to `false`

+ `mem "aa" (range "a" "b")` should evaluate to `true`

+ `mem "aa" (range "b" "c")` should evaluate to `false`


#### _Test Cases:_

For full credit your solution should pass 6/12 of the example evaluations given above.

# 3. Continuations

In Video 4.3, we saw that continuations can be used to make non-tail-recursive functions tail recursive (although a chain of continuations is still constructed in continuation-passing style, this chain doesn't reside on the system call stack).  Let's apply this technique to some familiar functions that aren't tail-recursive in the standard formulation. Copy the file `lab4/cps_functions.ml` from the public repository to your personal repository and fill in these
functions:

### `length_k`

`length_k : 'a list -> (int -> 'b) -> 'b` should compute the length of a list in continuation-passing style.  Some example evaluations:

+ `length_k [] (fun n -> n)` should evaluate to `0`

+ `length_k ["1"; "2"; "3"] (fun n -> [n])` should evaluate to `[3]`

+ `length_k [0; 0; 0; 0] string_of_int` should evaluate to `"4"`

### `find_all_k`

Recall that `find_all p ls` returns the list of all elements `e` of `ls` such `p e` evaluates to `true`.  Write the CPS version `find_all_k : ('a -> bool) -> 'a list -> ('a list -> 'b) -> 'b`.  Some example evaluations:

+ `find_all_k (fun _ -> true) [] (fun x -> x)` should evaluate to `[]`

+ `find_all_k ((=) 0) [0; 2; 0] List.length` should evaluate to `2`

+ `find_all_k ((<) 5) [6; 8; 2; 1] (fun x-> x)` should evaluate to `[6; 8]`

### `flip_tree_k`

The *flip* of a binary tree recursive swaps the left branch and the right branch of the tree at all levels, so the flip of `Node (10, Node (2, Node (5,Empty, Empty), Empty), Empty)` is the tree `Node (10, Empty, Node (2, Empty, Node (5, Empty, Empty)))`.  Write the CPS version `flip_tree_k : 'a btree -> ('a btree -> 'b) -> 'b`.  Some example evaluations:

+ `flip_tree_k Empty (fun x->x)` should evaluate to `Empty`

+ `flip_tree_k (Node ("root", Node("left", Empty, Empty), Node ("right", Empty, Node ("rr", Empty, Empty)))) (fun x -> x)` should evaluate to `Node ("root", Node ("right", Node ("rr", Empty, Empty), Empty), Node ("left", Empty, Empty))`

+ `flip_tree_k (Node ("root", Empty, Empty)) (fun _ -> "treebeard")` should evaluate to `"treebeard"`.

#### _Test Cases:_  

To get full credit for problem 3 your solution should pass at least 6/9 of the example evaluations.
