let rank x ls = List.fold_left(fun c r -> if r < x then c+1 else c) 0 ls

let prefixes ls = List.fold_left(fun lst r -> ((match lst with h::t -> h)@[r])::lst) [[]] ls