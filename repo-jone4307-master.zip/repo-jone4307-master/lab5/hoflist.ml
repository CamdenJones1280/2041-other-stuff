let mem  a ls = List.exists ((=) a ) ls 

let implode ls = List.fold_left(fun acc c -> acc ^ (String.make 1 c)) "" ls

let dot ls1 ls2 = List.fold_left2(fun acc e1 e2 -> acc +. (e1 *. e2)) 0.0 ls1 ls2

let onlySomes ls = List.fold_left(fun acc e -> if e <> None then e::acc else acc) [] ls

let isPrime n = List.for_all(fun x -> (n mod x) <> 0) (List.init(n/2) ((+) 2))