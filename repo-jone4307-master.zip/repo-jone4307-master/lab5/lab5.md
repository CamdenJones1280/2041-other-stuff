# Lab 5: List Higher-Order Functions

*CSci 2041: Advanced Programming Principles, Spring 2022 (Section 1)*

**Due:** Tuesday, February 22 at 11:59pm (CST)

In your local copy of the public `labs2041` repository, do a `git pull` to grab the files for this week's lab exercises.  Then let's get started practicing with higher-order list functions!

# 1.  Filters and maps

Create a file name `maps_and_filters.ml` in a `lab5` directory within your personal repo to hold your solutions to this problem.  Each problem but the last can be solved by a single call to `List.map` or `List.filter`.

### `fixduck`

Find all instances of `"goose"` in a `string list` and replace them with the right-thinking `"grey duck"`; for any other string but `"duck"`, append `" duck"`. Example evaluations: `fixduck ["duck"; "duck"; "goose"]` should evaluate to `["duck"; "duck"; "grey duck"]` and `fixduck ["purple"; "blue"; "duck"]` should evaluate to `["purple duck"; "blue duck"; "duck"]`. (`fixduck ["gooseduck"]` should evaluate to `["gooseduck duck"]`.)

### `hex_list`

Convert a list of integers into their hexadecimal string representations.  (Note: the most concise way to do this for a single string is with `(Printf.sprintf "%X")`.)  Examples: `hex_list [10]`  should evaluate to `["A"]` and `hex_list [19; 10; 31137]` should evaluate to `["13"; "A"; "79A1"]`.

### `de_parenthesize`

Remove all `'('` and `')'` chars from a char list. Examples: `de_parenthesize ['('; 'c'; 'a'; 'r'; ' '; '('; 'c'; 'd'; 'r'; ' '; 'l'; ')'; ')']` should evaluate to `['c'; 'a'; 'r'; ' '; 'c'; 'd'; 'r'; ' '; 'l']` and `de_parenthesize [':';'-'; ')']` should evaluate to `[':'; '-']`.

### `p_hack`

Given a list of `float*string` pairs, keep only pairs where the first element is less than `0.05`.  Example evaluations: `p_hack [(0.04, "Red meat vs cancer"); (0.1, "Internet vs cancer")]` should evaluate to `[(0.04, "Red meat vs cancer")]`, and `p_hack [(0.2, "random study"); (0.3, "random study 2"); (0.25, "random study 3"); (0.049, "random study 4")]` should evaluate to `[(0.049, "random study 4")]`.

### `make_assoc`

*Challenge* `make_assoc : string list list -> (int*int*string) list` takes as input a list of lists of strings, and returns a list of (row index,column index,string) tuples, so that, for instance the first string in the first list (row 1, column 1) is paired with `(1,1)`, the second string in the first list is paired with `(1,2)`, and the first string in the second list is paired with `(2,1)`.
Use `List.mapi` twice, and `List.flatten` the result.  Some example evaluations: `make_assoc [["a"]]` should evaluate to `[(1,1,"a")]` and  `make_assoc [["a";"b"];["c"]]` should evaluate to `[(1, 1, "a"); (1, 2, "b"); (2, 1, "c")]`.

#### _Test cases_

In order to receive full credit for this problem, your solution should agree with the example evaluations on at least 7/11 cases, and the file must not include a single `let rec` declaration.

# 2. Folds and Reductions

Each of the following functions can be implemented by a single call to List.fold_left or List.fold_right.  In a file named `folds.ml`, give implementations of:

### `rank`

`rank : 'a -> 'a list -> int` counts the number of items less than its first argument in its second argument, e.g. `rank 2 [1;3]` should evaluate to `1`, `rank "a" []` should evaluate to `0`, and `rank 3.14 [0.; 1.; 2.71828; 6.022e23]` should evaluate to `3`.

### `prefixes`

`prefixes : 'a list -> 'a list list` should return a list of all prefixes of the input list, e.g.
`prefixes []` should evaluate to `[[]]`, `prefixes [1; 2]` should evaluate to `[[1;2]; [1]; []]`; `prefixes ["a";"b";"c"]` should evaluate to `[["a"; "b"; "c"]; ["a;b"]; ["a"]; []]`.

### `suffixes`

`suffixes : 'a list  -> 'a list list` should return a list of all suffixes of the input list, e.g. `suffixes [1; 2]` should evaluate to `[[1;2]; [2]; []]`, and `suffixes ["a"]` should evaluate to `[["a"]; []]`, and `suffixes ['d';'e';'f']` should evaluate to `[['d';'e';'f'];['e';'f'];['f'];[]]`.


#### _Test Cases:_

In order to receive full credit, your solutions to this problem should agree on at least 6/9 of the example evaluations, and should not use any "let rec" bindings.

# 3. Using and choosing List HOFs

Create a file named `hoflist.ml` in your `lab5` folder to record your solutions to the problems in this section.

### Single-call implementations

Each of the following functions can be implemented via a single
call to one of our known higher-order list functions.  Give the
single-call implementation of each:

+ `mem (x : 'a) (lst : 'a list) : bool` returns `true` if `x` is an
  element of `lst` and `false` otherwise.  Example evaluations: `mem 2 [1;2]` should evaluate to `true`, and `mem "a" []` should evaluate to `false`.

+ `implode : char list -> string` takes a list of characters and
  squashes them into a string.  (Note: `String.make 1 c` makes a
  single-character string out of character `c`)  Example evaluations: `implode ['a'; ' '; 'f'; 'i'; 'n'; 'e'; ' '; 'm'; 'e'; 's'; 's']` should evaluate to `"a fine mess"`.

+ `dot : float list -> float list -> float` computes the dot product
  of its arguments.  Example evaluation: `dot [1.;2.;3.] [4.;5.;6.]` should evaluate to `32.`

+ `onlySomes : 'a option list -> 'a option list` removes all of the
  `None` variants from a list of `'a option` values.  `onlySomes [Some 1; None]` should evaluate to `[Some 1]` and `onlySomes []` should evaluate to `[]`.

### Double trouble

The following functions can be implemented by calling a list HOF on the output of another list HOF.  Give such implementations for each of them:

+ `isPrime : int -> bool` the integer `n` is prime if for every `i` between `2` and `n/2`, `n mod i <> 0`.  Some example evaluations: `isPrime 7` should evaluate to `true` and `isPrime 8` should evaluate to `false`.

+ `deOption : 'a option list -> 'a list` removes all of the `None` constructors from a list of `'a option` values, and returns the arguments of the `Some` constructors, so `deOption [Some 1; None; Some 3]` should evaluate to `[1;3]` and `deOption [None; None]` should evaluate to `[]`.

+ `overDiagonal : int list -> int list -> (int*int) list` takes a list of x-coordinates and a list of associated y-coordinates and returns only the (x,y) pairs such that y > x, e.g. `overDiagonal [0;3;5] [1;2;7]` should evaluate to `[(0,1);(5,7)]` and `overDiagonal [0;1;2] [0;1;2]` should evaluate to `[]`.


#### _Test Cases_  

To get full credit for problem 3 your solution should pass at least 8/12 of the example evaluations, and must not contain a single `let rec` binding.
