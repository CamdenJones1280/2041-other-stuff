(*no let recs are allowed for this section*)

let fixduck = List.map(fun x -> match x with 
|"goose" -> "grey duck"
| "duck" -> "duck"
| _ -> x ^ " duck")

let hex_list = List.map((Printf.sprintf "%X"))

let de_parenthesize = List.filter(fun x -> x<>'(' && x <> ')')