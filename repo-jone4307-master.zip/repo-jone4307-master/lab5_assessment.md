## Assessment for Lab 5

Run on February 23, 08:22:07 AM.

+ Pass: Change into directory "lab5".

### Part 1: Filters and maps

+  _1_ / _1_ : Pass: You are not allowed to use recursion.

   



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   fixduck ["duck"; "duck"; "goose"]
   ```
   matches the pattern `["duck"; "duck"; "grey duck"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   fixduck ["purple"; "blue"; "duck"]
   ```
   matches the pattern `["purple duck"; "blue duck"; "duck"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   fixduck ["gooseduck"]
   ```
   matches the pattern `["gooseduck duck"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   hex_list [10]
   ```
   matches the pattern `["A"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   hex_list [19; 10; 31137]
   ```
   matches the pattern `["13"; "A"; "79A1"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   de_parenthesize ['('; 'c'; 'a'; 'r'; ' '; '('; 'c'; 'd'; 'r'; ' '; 'l'; ')'; ')']
   ```
   matches the pattern `['c'; 'a'; 'r'; ' '; 'c'; 'd'; 'r'; ' '; 'l']`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   de_parenthesize [':';'-'; ')']
   ```
   matches the pattern `[':'; '-']`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   p_hack [(0.04, "Red meat vs cancer"); (0.1, "Internet vs cancer")]
   ```
   matches the pattern `[(0.04, "Red meat vs cancer")]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value p_hack
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   p_hack [(0.2, "random study"); (0.3, "random study 2"); (0.25, "random study 3"); (0.049, "random study 4")]
   ```
   matches the pattern `[(0.049, "random study 4")]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value p_hack
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   make_assoc [["a"]]
   ```
   matches the pattern `[(1,1,"a")]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value make_assoc
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   make_assoc [["a";"b"];["c"]]
   ```
   matches the pattern `[(1, 1, "a"); (1, 2, "b"); (2, 1, "c")]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value make_assoc
`


#### Subtotal: _8_ / _12_

### Part 2: Folds and reductions

+  _1_ / _1_ : Pass: You are not allowed to use recursion.

   



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   rank 2 [1; 3]
   ```
   matches the pattern `1`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   rank "a" []
   ```
   matches the pattern `0`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   rank 3.14 [0.; 1.; 2.71828; 6.022e23]
   ```
   matches the pattern `3`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   prefixes [1; 2]
   ```
   matches the pattern `[[1;2]; [1]; []]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   prefixes []
   ```
   matches the pattern `[[]]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   prefixes ["a";"b";"c"]
   ```
   matches the pattern `[["a"; "b"; "c"]; ["a";"b"]; ["a"]; []]`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   suffixes [1; 2]
   ```
   matches the pattern `[[1;2]; [2]; []]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: Unbound value suffixes
Hint: Did you mean prefixes?

```



+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   suffixes ['d';'e';'f']
   ```
   matches the pattern `[['d';'e';'f']; ['e';'f']; ['f']; []]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: Unbound value suffixes
Hint: Did you mean prefixes?

```



+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   suffixes ["a"]
   ```
   matches the pattern `[["a"]; []]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: Unbound value suffixes
Hint: Did you mean prefixes?

```



#### Subtotal: _7_ / _10_

### Part 3: Using and choosing List HOFs

+  _1_ / _1_ : Pass: You are not allowed to use recursion.

   



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   mem 2 [1;2]
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   mem "a" []
   ```
   matches the pattern `false`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   implode ['a'; ' '; 'f'; 'i'; 'n'; 'e'; ' '; 'm'; 'e'; 's'; 's']
   ```
   matches the pattern `"a fine mess"`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   dot [1.;2.;3.] [4.;5.;6.]
   ```
   matches the pattern `32.`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   onlySomes [Some 1; None]
   ```
   matches the pattern `[Some 1]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   onlySomes []
   ```
   matches the pattern `[]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   isPrime 7
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   isPrime 8
   ```
   matches the pattern `false`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   deOption [Some 1; None; Some 3]
   ```
   matches the pattern `[1;3]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value deOption
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   deOption [None; None]
   ```
   matches the pattern `[]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value deOption
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   overDiagonal [0;3;5] [1;2;7]
   ```
   matches the pattern `[(0,1);(5,7)]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value overDiagonal
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   overDiagonal [0;1;2] [0;1;2]
   ```
   matches the pattern `[]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: Unbound value overDiagonal
`


#### Subtotal: _9_ / _13_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

