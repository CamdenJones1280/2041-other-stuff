(* exn.ml - skeleton for lab exercise 6.1 *)

exception Reflect of int
let reflector x = raise (Reflect x)
let catcher r x = try (r x) with Reflect x -> x

let make_opt f e = 
  function y -> try Some (f y) with 
  | e -> None
  | _ -> Some (f y)
  
let rec safe_substr s b l = "" (* not right *)

let rec rm_assoc_exit k lst = [] (* fix this *)

let rm_assoc k lst = try rm_assoc_exit k lst with Exit -> lst
