
let uncomment f = 
  let ic = open_in f in 
  let next_char ( )= try Some (input_char ic) with End_of_file -> None in
  let rec file_loop acc acc2 trip = match next_char () with 
  | Some '\n' -> file_loop "" (acc::acc2) 0
  | Some '#' -> file_loop acc acc2 1
  | Some c ->  if trip = 0 then file_loop (acc ^ (String.make 1 c)) acc2 trip else file_loop acc acc2 trip
  | None -> List.rev (acc2) in 
  file_loop "" [] 0


  (*ok start on the second one just need to figure out the conversion to sci note*)
  let tabulate lst f =
    let oc = open_out f in
    let () = List.iter(fun (m,n)-> Printf.fprintf oc "%4.2e,%4.2e\n" m n) lst in
    close_out oc
