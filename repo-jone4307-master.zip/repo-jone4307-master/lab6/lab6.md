# Lab 6: Exceptions, IO and Modules

*CSci 2041: Advanced Programming Principles, Spring 2022 (Section 1)*

**Due:** Tuesday, March 1 at 11:59pm (CST)

In your local copy of the public `labs2041` repository, do a `git pull` to grab the files for this week's lab exercises.  Then let's get started!

# 1.  Exceptions

In the public repo for this exercise you will find a file named `exn.ml` where your solutions can be recorded.

### Raising and handling exceptions

First let's start by writing some code to declare, raise, and handle exceptions. At the top of `exn.ml`, add a declaration for a new `exn` constructor called `Reflect` that can be applied to a value of type `int`.  Then complete the definition of the function `reflector : int -> 'a`, which always raises a `Reflect` applied to its argument.  Finally, complete the definition of the function `catcher : ('a -> int) -> 'a -> int`, so that `catcher r x` applies `r` to `x`, and handles the exception `Reflect y` by returning `y`.  Here are the tests we will apply:

+ `(Reflect 1)` should have type `exn`
+ `try (reflector 0) with Reflect 0 -> true` should evaluate to `true`
+ `catcher reflector 17` should evaluate to `17`

### Converting to options

Several functions in the OCaml standard library have two versions: a standard version that can raise an exception when called with certain inputs, and an `_opt` version that instead returns a `Some` constructor on is results, or `None` for inputs that can result in the exception.  So for instance, `List.assoc k l` raises `Not_found` when no input associated with `k` is found, whereas `List.assoc_opt` returns `None`; and `List.hd l` returns the head of list `l` when it is not empty and raises `Failure "hd"` otherwise, whereas `List.hd_opt l` returns `None` if its argument is `[]`.  Complete the definition of a generic "option converter" `make_opt : ('a -> 'b) -> exn -> 'a -> 'b option` so that `make_opt f e` returns a *function* that takes an input `y` and evaluates to `Some (f y)` unless the (specific) expection `e` is raised, in which case it evaluates to `None`.  Some example evaluations:

+ `(make_opt List.hd (Failure "hd")) []` should evaluate to `None`
+ `(make_opt List.hd (Failure "hd")) [1]` should evaluate to `Some 1`
+ `let assoc_opt k = make_opt (List.assoc k) Not_found in assoc_opt 3 [(2,"a")]` should evaluate to `None`
+ `let assoc_opt k = make_opt (List.assoc k) Not_found in assoc_opt 3 [(3,"a")]` should evaluate to `Some "a"`

### Guarding substring cases

The `String.sub` function for extracting substrings can be tricky, because it expects a beginning index and a substring _length_ rather than an ending index (So `String.sub "Hello!" 2 3` returns `"llo"`, not `"ll"`).  So programmers can either forget and pass an index *or* make an off-by-one error, in either case potentially asking for a substring that runs past the end of the string, and causing an `Invalid_argument` exception to be raised.  Let's write a "safe" version `safe_substr : string -> int -> int -> string` that optimistically calls `String.sub` with its arguments, but then handles a potential `Invalid_argument` exception by reducing the substring length so that it doesn't run past the end of the string.  Some example evaluations:

+ `safe_substr "abc" 1 1` should evaluate to `"b"`.
+ `safe_substr "abc" 1 15` should evaluate to `"bc"`.
+ `safe_substr "ab" (-1) 1` should still raise an `Invalid_argument` exception.

### Shortcut evaluation

Another potential use of exceptions discussed in Hickey's chapter 9 is in case a "normal" return from a function would require a large amount of unnecessary work.  For instance, consider the following function:

```ocaml
let rec sorted_insert lst e = match lst with
| [] -> [e]
| h::t when h=e -> lst
| h::t -> if h > e then e::lst else h::(sorted_insert t e)
```

If the element `e` is already in the list but near the end, then this procedure builds another copy of the list for no good reason.  We could check whether `e` was in the list before building the list, but that would require twice as much work when `e` was not in the list.  An alternative is to raise the built-in but unused `Exit` exception to signal that the original list should be returned:

```ocaml
let sorted_insert lst e =
  let rec worker = function [] -> [e]
  | h::t when h=e -> raise Exit
  | h::t as ls -> if h > e then e::ls else h::(worker t)
  in try (worker lst) with Exit -> lst
```

The function `List.remove_assoc : 'a -> ('a*'b) list -> ('a * 'b) list` removes the value (if any) associated with its first argument in the associative list that is its second argument.  It has a similar problem (reaching the end of the list means copying the entire original list).  In `exn.ml`, fill in the function `rm_assoc_exit` so that the `rm_assoc` function behaves the same as `remove_assoc`.  Some example evaluations:

+ `rm_assoc_exit 3 [(2,"v1"); (3,"v2")]` should evaluate to `[(2,"v1")]`
+ `rm_assoc_exit 3 [(3,"v")]` should evaluate to `[]`
+ `rm_assoc_exit 2 [(3,"v")]` should raise `Exit`
+ `rm_assoc 2 [(3,"v")]` should evaluate to `[(3,"v")]`  

#### _Test cases_

In order to receive full credit for this problem, your solution should agree with the example evaluations on at least 7/14 cases.

# 2. Writing and reading files

Your answers for this exercise should be recorded in a file named `io.ml` in the `lab6` folder.

## uncomment

In a python program, any thing after the first `#` character on a line is in a comment, so it doesn't affect the behavior of the program.  Write a function `uncomment : string -> string list` such that `uncomment f1` opens the file named `f1` and evaluates to a list of all of the lines of `f1` with any commented portions removed.  There are three example files `short1.py`, `short2.py`, and `short3.py` in the `labex6` directory of the public repo.  If you copy them to the directory in which you are running `utop`, then:

+ `uncomment "short1.py"` should evaluate to `[""; "print(\"hello world!\") "; "x = 4*3"]`
+ `uncomment "short2.py"` should evaluate to `[""; ""; "x = 4*3"]`
+ `uncomment "short3.py"` should evaluate to `["print(\"hello world!\") "; "x = 4*3\\"; "  * 7"]`

## tabulate

Write a function `tabulate : (float*float) list -> string -> unit` that takes as input a list of `float`s, and a file name, and writes the elements of the list to a file.  Each pair should be in scientific notation, with two digits of precision, separated by a comma and one space, and followed by a newline, except for the last pair.  So for example:

+ `tabulate [] "out1.txt"` should produce an empty file
+ `tabulate [(1.2313,12324.2)] "out2.txt"` should produce a file like :
    ```
    1.23e+00,1.23e+04
    ```
+ `tabulate [(234.5, 678901.2); (0.00125,0.00000101)] "out3.txt"` should produce a file like:
    ```
    2.34e+02,6.79e+05
    1.25e-03,1.01e-06
    ```

Note: there should *not* be a blank line at the beginning or end of these output files.


#### _Test Cases:_

In order to receive full credit, your solutions to this problem should agree on at least 4/6 of the example cases.

# 3.  Interfaces and implementations

The files `rQ3.mli` and `rQ3.ml` contain the interface and implementation for a ring queue of size 3.  (In a ring queue or ring buffer of size k, only the k most recently enqueued values can be accessed.  They are sometimes used in software for embedded systems with very restricted memory.  Usually not with k=3, though.)

Unfortunately, the code is broken: you can't compile `rQ3.ml` against the interface `rQ3.mli`.  The task for this exercise is to *fix* these files so that:

+ when compiled by `ocamlc -c rQ3.mli rQ3.ml` (in a clean directory with no `rQ3.cmi` or `rQ3.cmo` files present) the compiler will succeed.  (worth 5 points)

When the resulting object file (`rQ3.cmo`) is `#load`ed in utop, the following will be true:
+ The test `RQ3.empty = (None, None, None)` will fail with a type error.
+ The expression `try RQ3.peek RQ3.empty with RQ3.EmptyQ -> true` will evaluate to `true`
+ The expression `RQ3.peek (RQ3.add 1 RQ3.empty)` evaluates to `1`
+ The expression `RQ3.fold (+) 0 RQ3.empty` evaluates to `0`
+ The expression `RQ3.pop (RQ3.add 2 RQ3.empty) = RQ3.empty` evaluates to `true`

#### _Test Cases_  

To get full credit for problem 3 your solution should earn at least 7/10 points.
