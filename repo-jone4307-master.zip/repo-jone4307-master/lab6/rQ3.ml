(* rQ3.ml - implementation *)

type 'a q = ('a option) * ('a option) * ('a option)
exception EmptyQ

let empty : 'a q = (None, None, None)
let add x (q1,q2,q3) = match (q1,q2,q3) with
| (None,None,None) -> ((Some x), None, None)
| (Some _, None, None) -> (q1, Some x, None)
| (Some _, Some _, None) -> (q1, q2, Some x)
| _ -> (q2, q3, Some x)


let pop (q1,q2,q3) = (q2, q3, None)
let peek (q1,q2,q3) = match q1 with None -> raise EmptyQ | Some v -> v

let rec fold f acc (q1,q2,q3) = match q1 with None -> acc
| Some v -> fold f (f acc q1) (q2, q3, None)
