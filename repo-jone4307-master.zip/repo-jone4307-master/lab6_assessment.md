## Assessment for Lab 6

Run on March 02, 10:38:27 AM.

+ Pass: Change into directory "lab6".

### Part 1: Exceptions

+  _1_ / _1_ : Pass: Check that expression `(Reflect 1)` following file exn.ml has type `exn`

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   try (reflector 0) with Reflect 0 -> true
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   catcher reflector 17
   ```
   matches the pattern `17`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   (make_opt List.hd (Failure "hd")) []
   ```
   matches the pattern `None`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   (make_opt List.hd (Failure "hd")) [1]
   ```
   matches the pattern `Some 1`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   let assoc_opt k = make_opt (List.assoc k) Not_found in assoc_opt 3 [(2,"a")]
   ```
   matches the pattern `None`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   let assoc_opt k = make_opt (List.assoc k) Not_found in assoc_opt 3 [(3,"a")]
   ```
   matches the pattern `Some "a"`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   safe_substr "abc" 1 1
   ```
   matches the pattern `"b"`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string = ""
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   safe_substr "abc" 1 15
   ```
   matches the pattern `"bc"`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string = ""
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   try safe_substr "ab" (-1) 1 with Invalid_argument _ -> "pass"
   ```
   matches the pattern `"pass"`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string = ""
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   rm_assoc_exit 3 [(2,"v1"); (3,"v2")]
   ```
   matches the pattern `[(2,"v1")]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : 'a list = []
`


+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   rm_assoc_exit 3 [(3,"v")]
   ```
   matches the pattern `[]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   try [] = rm_assoc_exit 2 [(3,"v")] with Exit -> true
   ```
   matches the pattern `true`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   rm_assoc 2 [(3,"v")]
   ```
   matches the pattern `[(3,"v")]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : (int * string) list = []
`


#### Subtotal: _9_ / _14_

### Part 2: Writing and reading files

Wrote required input files

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   uncomment "short1.py"
   ```
   matches the pattern `[""; "print(\"hello world!\") "; "x = 4*3"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   uncomment "short2.py"
   ```
   matches the pattern `[""; ""; "x = 4*3"]`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   uncomment "short3.py"
   ```
   matches the pattern `["print(\"hello world!\") "; "x = 4*3\\"; "  * 7"]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   tabulate [] "out1.txt"
   ```
   matches the pattern `()`.

   




+  _1_ / _1_ : Pass: Contents of file out1.txt are correct

+ Pass: 
Check that the result of evaluating
   ```
   tabulate [(1.2313,12324.2)] "out2.txt"
   ```
   matches the pattern `()`.

   




+  _1_ / _1_ : Pass: Contents of file out2.txt are correct

+ Pass: 
Check that the result of evaluating
   ```
   tabulate [(234.5, 678901.2); (0.00125,0.00000101)] "out3.txt"
   ```
   matches the pattern `()`.

   




+  _1_ / _1_ : Pass: Contents of file out3.txt are correct

#### Subtotal: _6_ / _6_

### Part 3: Interfaces and implementations

Cleaned up conflicting files

Wrote required input files

+  _5_ / _5_ : Pass: Check that an OCaml file "rQ3.ml" has no syntax or type errors.

    OCaml file "rQ3.ml" has no syntax or type errors.



+  _1_ / _1_ : Pass: Check that expression `RQ3.empty` following file null.ml has type `'a RQ3.q`

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   try RQ3.peek RQ3.empty with RQ3.EmptyQ -> true
   ```
   matches the pattern `true`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   RQ3.peek (RQ3.add 1 RQ3.empty)
   ```
   matches the pattern `1`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   RQ3.fold (+) 0 RQ3.empty
   ```
   matches the pattern `0`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: This expression has type int -> int -> int
       but an expression was expected of type int -> 'a option -> int
       Type int is not compatible with type 'a option 

```



+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   RQ3.pop (RQ3.add 2 RQ3.empty) = RQ3.empty
   ```
   matches the pattern `true`.

   




#### Subtotal: _9_ / _10_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

