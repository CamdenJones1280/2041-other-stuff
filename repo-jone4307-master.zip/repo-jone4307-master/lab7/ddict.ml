module type Elt = sig
  type k
  type v
  val eq : k -> k -> bool
end

module type Dict = sig
  type t
  type k
  type v
  val empty : t
  val add : k -> v -> t -> t
  val lookup : k -> t -> v
end

module ListDict = struct
    type ('k,'v) t = ('k * 'v) list
    let empty = []
    let add k v d = (k,v)::d
    let lookup k d = List.assoc k d
    let rec update k v d = match d with
      | [] -> [(k,v)]
      | (key,_)::t when key=k -> (k,v)::t
      | kv::t -> kv::(update k v t)
    let rec fold f a d = List.fold_left f a d
  end

(* Add ListDict Functor here *)
module EqListDict (X : Elt) = struct
  type ('k,'v) t = ('k * 'v) list
  let empty = []
  let add k v d = (k,v)::d
  let rec lookup k d = match d with 
  | h::t -> if X.eq k (fst h) then snd h else lookup k t
  | [] -> raise Not_found
end

(* Add DefaultElt signature here *)
module type DefaultElt = sig 
  type k
  type v
  val eq : k -> k -> bool
  val default : v
end

(* DefaultDict functor: *)
module DefaultDict (X:DefaultElt)= struct
  type ('k,'v) t = ('k * 'v) list
  let empty = []
  let add k v d = (k,v)::d
  let rec lookup k d = match d with 
  | h::t -> if X.eq k (fst h) then snd h else lookup k t
  | [] -> X.default 
end

(* DefaultDictFunctor: *)
module DefaultDictFunctor = struct end