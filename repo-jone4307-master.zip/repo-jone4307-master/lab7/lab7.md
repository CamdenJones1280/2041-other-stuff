# Lab Exercise 7: Modules and Functors

*CSci 2041: Advanced Programming Principles, Fall 2020 (Section 10)*

**Due:** Tuesday, March 15 at 11:59pm (CST)

In your local copy of the public `labs2041` repository, do a `git pull` to grab the files for this week's lab exercises.  Then let's get started!

# 1.  Module code

In this section, we'll develop some simple modules and functors, working in the file `modules.ml`  

### Stack module

In `modules.ml`, add a module `Stack` that defines a type `'a t = 'a list`; the functions `push : 'a -> 'a t -> 'a t`, `pop : 'a t -> 'a t`, and `top : 'a t -> 'a`; and the value `empty : 'a t`.   (`push` conses a new top onto the stack, `pop` returns the rest or `invalid_arg "pop"` on an empty stack; `top` returns the head or `invalid_arg "top"` on an empty stack; `empty` is `[]`).  There will be one test case for each item in the signature, and test evaluations for `Stack.pop (Stack.push "a" Stack.empty) = Stack.empty`, which should evaluate to `true`) and `Stack.top (Stack.push 17 Stack.empty)`, which should evaluate to `17`.

### `Nat`ural arithmetic

#### `Nat` module

Define a module `Nat` that defines the type `t = Zero | Next of t`, and provides

+ functions `to_int : Nat.t -> int`, `of_int : int -> Nat.t`,  defined by:

```ocaml
let rec to_int = function Zero -> 0 | Next n -> 1 + (to_int n)
let rec of_int = function 0 -> Zero | n -> Next (of_int (n-1))
```

+ The value `zero : Nat.t`, and
+ functions `incr : Nat.t -> Nat.t`, and `decr : Nat.t -> Nat.t` (Calling `Nat.decr Zero` should raise `Invalid_argument "decr"`, but this won't be a test case).  

Test cases:

+ `let x = Nat.zero in ((Nat.decr (Nat.incr x)) = x)` evaluates to `true`
+ `Nat.to_int (Nat.incr Nat.zero)` evaluates to `1`
+ `Nat.to_int (Nat.of_int 3)` evaluates to `3`.  

#### `NatSig` signature

Define a module signature `NatSig` that requires a type `t`, a value `zero : t` and the functions `incr : t -> t` and `decr : t -> t`.  Test cases will check for each of these belonging to the signature.


#### _Test cases_

In order to receive full credit for this problem, your solution should agree with the example evaluations on at least 9/14 cases.

# 2. Writing Functors

In this section and the next question, we'll look at dictionaries, data structures that map from keys of type `k` to values of type `v`.  The file `ddict.ml` give an associative list implementation of dictionaries, and you will also implement a function dictionary in Part 3.   In this exercise, we'll consider dictionaries that are parameterized in two additional aspects:

* the equality function that determines whether two keys are the same or not,

* the "default value" to return if a key is not present in the dictionary

The file `ddict.ml` contains some starting pieces: a signature `Elt` that will provide the key type, value type, and equality function, and a signature `Dict` that our functors will satisfy.

### EqListDict

Let's start by filling in the `EqListDict` functor, which has "kind" `functor(Elt) -> Dict`, that is, the functor should take a module satisfying `Elt` and create a module satisfying `Dict`:

+ The empty value is just `[] : k*v list`
+ The add function just conses its key and value arguments onto the front of the list
+ The lookup function should walk through the list, using the Elt module's `eq` function to compare keys, and return the value associated to the first key matching its key argument.  If no matching key is found, EqListDict should raise `Not_found`.

In order to use the resulting `dict` module, you will need to expose the types `k` and `v` in the functor signature.

+ Some example evaluations:

    * `let module DII = EqListDict(struct type k = int type v = int let eq = (=) end) in let d1 = DII.empty in let d2 = DII.add 2 17 d1 in DII.lookup 2 d2` should evaluate to `17`

    * `let module DSLI = EqListDict(struct type k = string type v = int let eq s1 s2 = String.length s1 = String.length s2 end) in let d = DSLI.add "aa" 42 DSLI.empty in DSLI.lookup "bb" d` should evaluate to `42`.

    * `let module NeverDict = EqListDict(struct type k = int type v = int let eq k1 k2 = false end) in let d = NeverDict.add 1 1 NeverDict.empty in NeverDict.lookup 1 d` should raise `Not_found`

### DefaultDict

Now make the `DefaultElt` signature, which just includes the `Elt` signature plus requires a `default` value of type `v`.  Write a functor, `DefaultDict` that acts on a module of type `DefaultEt`, and implements the `Dict` signature with appropriate sharing.  `DefaultDict` will look nearly identical to `EqListDict` except that where `EqListDict` raises `NotFound`, the new functor should return the default value in the DefaultElt module it received as input. Some example evaluations:

  * `let module M = DefaultDict(struct type k = int type v = int let default = -1 let eq = (=) end) in M.lookup 1 M.empty` should evaluate to `-1`.

  * `let module M = DefaultDict(struct type k = int type v = string let default = "" let eq = (=) end) in M.lookup 2 (M.add 2 "a" M.empty)` should evaluate to `"a"`.

  * `let module M = DefaultDict(struct type k = int type v = string let default = "" let eq = (=) end) in M.lookup 3 (M.add 2 "a" M.empty)` should evaluate to `""`.

### DefaultDictFunctor
Finally, let's make a functor that converts an arbitrary `Dict` into a `DefaultDict`: `DefaultDictFunctor` should act on a `DefaultElt` module and a `Dict` module.  `DefaultDictFunctor(E)(D)` should include `D`, and overwrite the `lookup` function by calling `D.lookup` in a `try...catch` wrapper that returns `E.default` with `Not_found` is raised.  Example evaluations:

  * `let module E = struct type k = int type v = int let default = (-1) let eq = (=) end in
     let module D = EqListDict(E) in let module DD = DefaultDictFunctor(E)(D) in
     DD.lookup 1 DD.empty` should evaluate to `-1`.

  * `let module E = struct type k = int type v = int let default = (-1) let eq _ _ = false end in
    let module D = EqListDict(E) in let module DD = DefaultDictFunctor(E)(D) in
    DD.lookup 1 (DD.add 1 3 DD.empty)` should evaluate to `-1`.

  * `let module E = struct type k = string type v = string let default = "" let eq s1 s2 = String.lowercase_ascii s1 = String.lowercase_ascii s2 end in
      let module D = EqListDict(E) in let module DD = DefaultDictFunctor(E)(D) in
      DD.lookup "A" (DD.add "a" "yo" DD.empty)` should evaluate to `"yo"`.


#### _Test Cases:_

In order to receive full credit, your solutions to this problem should agree on at least 6/9 of the example cases.

# 3.  Function Dictionaries

Another method of implementing dictionaries is by functions, e.g. a
dictionary with keys of type `'k` and values of type `'v` is a
function `d : 'k -> 'v` such that looking up the binding for `key` is
accomplished by calling `(d key)`.  In this implementation:

+ The empty dictionary is the function `empty = fun k -> raise Not_found`

+ Adding `(key,vl)` binding is accomplished by creating a new function
that tests whether its input `k` is `key` (and returns `vl` if so) and otherwise
calls the old dictionary with `k`. (i.e. if `d` is the old dictionary, adding `(key,vl)` to `d` should result in the function `fun k -> if (k=key) then vl else (d k)`)

+ Updating a binding is identical to adding the binding.

In `fdict.ml`, fill in the definition of the `FunDict`
module, declaring the type of `('k,'v)` function dictionaries, and
implementing the `empty` function dictionary, and the functions `add : 'k -> 'v ->
('k,'v) t -> ('k,'v) t`, `update`, and `lookup : 'k -> ('k,'v) t ->
'v`.  

## Abstraction

Of course, as the modules are implemented so far, the details of the
data structures are transparent.  In order to make the types abstract,
we'll need to restrict the `FunDict` and `ListDict`,
modules to a signature with abstract representation for the type
`('k,'v) t`.  Add a signature declaration for a `Dict` module
signature that has a type (`('k,'v) t`), the `empty` dictionary, the
`add` function, the `lookup` function, and the `update` function.
Restrict `FunDict` to this signature.

## Functors

The `fdict.ml` file also contains the beginning of the declaration for
a functor, `DictTest`, that allows us to test whether two
dictionary modules have the same behavior for some input.  Uncomment
and complete the `DictTest` functor, so that the `DictTest.test`
function adds the list of bindings in `ins_list` to an empty `DT1.t`
and an empty `DT2.t`, then tests whether the two dictionaries give back
the same values when looking up each element in `test_list`.  `test` should return a list of any keys on which the two dictionaries differ.

## Test them out

Add a line declaring the `FLTester` module, which instantiates `DictTest` with the
`FunDict` module as `DT1` and the `ListDict` module as `DT2`.  Follow this line with a
let declaration that binds the name `agree` to the result of checking that `FLTester.test` on an appropriately-typed input has output `[]`.


#### _Test Cases_  

To get full credit for problem 3 your solution should earn at least 6/9 points.
