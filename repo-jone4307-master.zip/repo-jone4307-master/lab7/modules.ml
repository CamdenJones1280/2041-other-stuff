module Stack = struct 
  type 'a t = 'a list
  let empty = []
  let push a x = [a] @ x
  let pop x = match x with 
  | [] -> invalid_arg "pop"
  | h::t -> t 
  let top x = match x with 
  | h::t -> h
  | empty -> invalid_arg "top"
end

module Nat = struct 
  type t = Zero | Next of t
  let rec to_int = function Zero -> 0 | Next n -> 1 + (to_int n)
  let rec of_int = function 0 -> Zero | n -> Next (of_int (n-1))
  let zero = Zero
  let incr x = of_int((to_int x) + 1)
  let decr x = of_int((to_int x) -1)
end

(*idk if i just dont understand the question or what*)
module type NatSig = sig
  type t 
  val zero : t
  val incr : t -> t
  val decr : t -> t
end

