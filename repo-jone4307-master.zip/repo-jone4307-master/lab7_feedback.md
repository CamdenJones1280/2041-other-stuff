### Feedback for Lab 7

Run on March 15, 12:11:13 PM.

+ Pass: Change into directory "lab7".

+ Pass: Check that file "modules.ml" exists.

+ Pass: Found definition for stack type in modules.ml

+ Pass: Found definition for push in modules.ml

+ Pass: Found definition for pop in modules.ml

+ Pass: Found definition for top in modules.ml

+ Pass: Found definition for empty in modules.ml

+ Pass: 
Check that the result of evaluating
   ```
   Stack.pop (Stack.push "a" Stack.empty) = Stack.empty
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   Stack.top (Stack.push 17 Stack.empty)
   ```
   matches the pattern `17`.

   




+ Pass: 
Check that the result of evaluating
   ```
   let x = Nat.zero in ((Nat.decr (Nat.incr x)) = x)
   ```
   matches the pattern `true`.

   




+ Pass: 
Check that the result of evaluating
   ```
   Nat.to_int (Nat.incr Nat.zero)
   ```
   matches the pattern `1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   Nat.to_int (Nat.of_int 3)
   ```
   matches the pattern `3`.

   




+ Pass: Found definition for NatSig.t in modules.ml

+ Pass: Found definition for NatSig.zero in modules.ml

+ Pass: Found definition for NatSig.incr in modules.ml

+ Pass: Found definition for NatSig.decr in modules.ml

+ Pass: Check that file "ddict.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   let module DII = EqListDict(struct type k = int type v = int let eq = (=) end) in let d1 = DII.empty in let d2 = DII.add 2 17 d1 in DII.lookup 2 d2
   ```
   matches the pattern `17`.

   




+ Pass: 
Check that the result of evaluating
   ```
   let module DSLI = EqListDict(struct type k = string type v = int let eq s1 s2 = String.length s1 = String.length s2 end) in let d = DSLI.add "aa" 42 DSLI.empty in DSLI.lookup "bb" d
   ```
   matches the pattern `42`.

   




+ Pass: 
Check that the result of evaluating
   ```
   try (let module NeverDict = EqListDict(struct type k = int type v = int let eq k1 k2 = false end) in let d = NeverDict.add 1 1 NeverDict.empty in NeverDict.lookup 1 d) with Not_found -> (-1)
   ```
   matches the pattern `-1`.

   




+ Pass: 
Check that the result of evaluating
   ```
   let module M = DefaultDict(struct type k = int type v = int let default = -1 let eq = (=) end) in M.lookup 1 M.empty
   ```
   matches the pattern `(-1)`.

   




+ Pass: 
Check that the result of evaluating
   ```
   let module M = DefaultDict(struct type k = int type v = string let default = "" let eq = (=) end) in M.lookup 2 (M.add 2 "a" M.empty)
   ```
   matches the pattern `"a"`.

   




+ Pass: 
Check that the result of evaluating
   ```
   let module M = DefaultDict(struct type k = int type v = string let default = "" let eq = (=) end) in M.lookup 3 (M.add 2 "a" M.empty)
   ```
   matches the pattern `""`.

   




+ Fail: 
Check that the result of evaluating
   ```
   let module E = struct type k = int type v = int let default = (-1) let eq = (=) end in let module D = EqListDict(E) in let module DD = DefaultDictFunctor(E)(D) in DD.lookup 1 DD.empty
   ```
   matches the pattern `(-1)`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: This module is not a functor; it has type sig  end
`


+ Fail: 
Check that the result of evaluating
   ```
   let module E = struct type k = int type v = int let default = (-1) let eq _ _ = false end in let module D = EqListDict(E) in let module DD = DefaultDictFunctor(E)(D) in DD.lookup 1 (DD.add 1 3 DD.empty)
   ```
   matches the pattern `-1`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: This module is not a functor; it has type sig  end
`


+ Fail: 
Check that the result of evaluating
   ```
   let module E = struct type k = string type v = string let default = "" let eq s1 s2 = String.lowercase_ascii s1 = String.lowercase_ascii s2 end in let module D = EqListDict(E) in let module DD = DefaultDictFunctor(E)(D) in DD.lookup "A" (DD.add "a" "yo" DD.empty)
   ```
   matches the pattern `"yo"`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
[0m[1;31mError[0m: This module is not a functor; it has type sig  end
`


+ Pass: Check that file "fdict.ml" exists.

+ Pass: type t appears in Dict sig

+ Pass: empty appears in Dict sig

+ Pass: add appears in Dict sig

+ Pass: lookup appears in Dict sig

+ Pass: update appears in Dict sig

+ Pass: FunDict appears in dict.ml

+ Pass: ListDict appears in dict.ml

+ Fail: FLTester in dict.ml

+ Fail: agree in dict.ml

+ Fail: DictTest functor defined

