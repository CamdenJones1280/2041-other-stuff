### Feedback for Lab 8

Run on March 22, 13:55:52 PM.

+ Pass: Change into directory "lab8".

+ Pass: Check that file "syntax.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   e_collatz
   ```
   matches the pattern `Let ("n", IntC 31, Let ("n2", Div (Name "n", IntC 2), If (Eq (Mul (Name "n2", IntC 2), Name "n"), Name "n2", Add (Mul (IntC 3, Name "n"), IntC 1))))`.

   




+ Pass: 
Check that the result of evaluating
   ```
   e_ifchain
   ```
   matches the pattern `Let ("x", Sub (IntC 42, IntC 17), If (And (Gt (Name "x", IntC 17), BoolC true), If (Or (Lt (Name "x", IntC 31), BoolC false), IntC 1, IntC 0), IntC (-1)))`.

   




+ Pass: 
Check that the result of evaluating
   ```
   e_uclid
   ```
   matches the pattern `Let ("p1", Add (Mul (IntC 2, IntC 3), IntC 1),Let ("p2", Add (Mul (IntC 5, Sub (Name "p1", IntC 1)), IntC 1), Add (Mul (IntC 7, Sub (Name "p2", IntC 1)), IntC 1)))`.

   




+ Fail: Check that expression `BLet ("cnd", BoolC true, If(BName "cnd", IntC 1, IntC (-1)))` following file syntax.ml has type `expr`There was an error: File "(stdin)", line 93, characters 24-28:
93 | let v_d4xgt5vz : expr = BLet ("cnd", BoolC true, If(BName "cnd", IntC 1, IntC (-1)))
                             ^^^^
Error: This variant expression is expected to have type expr
       The constructor BLet does not belong to type expr
Hint: Did you mean Let?


+ Fail: Check that expression `And (BName "bvar", BoolC true)` following file syntax.ml has type `boolExpr`There was an error: File "(stdin)", line 93, characters 33-38:
93 | let v_4sg4m3t3 : boolExpr = And (BName "bvar", BoolC true)
                                      ^^^^^
Error: This variant expression is expected to have type boolExpr
       The constructor BName does not belong to type boolExpr


+ Fail: 
Check that the result of evaluating
   ```
   beval (BName "v") [] [("v", true)]
   ```
   matches the pattern `true`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: This variant expression is expected to have type boolExpr
       The constructor BName does not belong to type boolExpr

```



+ Fail: 
Check that the result of evaluating
   ```
   eval (BLet ("c", BoolC false, If (BName "c", IntC 1, IntC 17))) [] []
   ```
   matches the pattern `17`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: This variant expression is expected to have type expr
       The constructor BLet does not belong to type expr
Hint: Did you mean Let?

```



+ Pass: Check that file "static.ml" exists.

+ Pass: Check that expression `Print (IntC 2)` following file static.ml has type `expr`

+ Pass: Check that expression `Eq (StringC "a", SFirst (StringC "ab"))` following file static.ml has type `expr`

+ Pass: Check that expression `Concat (StringC "a", SRest (StringC "b"))` following file static.ml has type `expr`

+ Pass: Check that expression `UnitC` following file static.ml has type `expr`

+ Pass: 
Check that the result of evaluating
   ```
   typeof (Concat (StringC "a", SRest (StringC "b"))) []
   ```
   matches the pattern `StringT`.

   




+ Pass: 
Check that the result of evaluating
   ```
   unbound (Print (IntC 3)) []
   ```
   matches the pattern `[]`.

   




+ Pass: 
Check that the result of evaluating
   ```
   eval (Concat (SFirst (StringC "ab"), SRest (StringC "ab"))) []
   ```
   matches the pattern `StringR "ab"`.

   




+ Pass: Check that file "imperative.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   e_gcd
   ```
   matches the pattern `
Let ("m",IntC 65537,
Let ("n",IntC 262144,
Seq([
While (Not (Eq (Name "m", Name "n")),
    If (Gt (Name "m", Name "n"),
        Set ("m", Sub (Name "m", Name "n")),
        Set ("n", Sub (Name "n", Name "m"))));
Name "m"])))
`.

   




+ Pass: 
Check that the result of evaluating
   ```
   e_rsqr
   ```
   matches the pattern `
Let ("p", IntC 3,
Let ("x", IntC 15,
Seq([
While (Gt (Name "x", IntC 0),
    Seq([
    Set ("x",Sub (Name "x", IntC 1));
    Set ("p",Mul (Name "p", Name "p"));
    While (Gt (Name "p", IntC 65521),
        Set ("p", Sub (Name "p", IntC 65521))
    )])
);
Name "p"])))
`.

   




+ Fail: 
Check that the result of evaluating
   ```
   unbound (Set ("x",IntC 7)) []
   ```
   matches the pattern `["x"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string list = ["change_me"]
`


+ Fail: 
Check that the result of evaluating
   ```
   unbound (Set ("x",Name "y")) ["x"]
   ```
   matches the pattern `["y"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string list = ["change_me"]
`


+ Fail: 
Check that the result of evaluating
   ```
   unbound (Seq ([Name "x"; Let("y", IntC 7, BoolC true); Set ("y",BoolC false)])) []
   ```
   matches the pattern `["x";"y"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string list = ["change_me"]
`


+ Fail: 
Check that the result of evaluating
   ```
   unbound (Seq ([Name "x"; Let("y", IntC 7, BoolC true); Set ("y",BoolC false)])) ["x";"y"]
   ```
   matches the pattern `[]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string list = ["change_me"]
`


+ Fail: 
Check that the result of evaluating
   ```
   unbound (While (Name "b", Set ("loop", Add (Name "loop", IntC 1)))) []
   ```
   matches the pattern `["b"; "loop"; "loop"]`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : string list = ["change_me"]
`


