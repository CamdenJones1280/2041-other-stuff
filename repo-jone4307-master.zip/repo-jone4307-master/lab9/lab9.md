# Lab 9: Lazy evaluation

*CSci 2041: Advanced Programming Principles, Spring 2022 (Section 01)*

**Due:** Tuesday, March 29 at 11:59pm (CST)

In your local copy of the public `labs2041` repository, do a `git pull` to grab the files for this week's lab exercises.  Then let's get started!

# 1. Expression tree functions and call-by-name

The file [`lab9/funval.ml`](funval.ml) extends our simple program representation to include functions and function applications.  We'll encode a few simple functions and then implement a program transformation on expressions in this file.

### Encoding Simple functions

The `funval.ml` file already has let declarations for three function values, that we should fill in.

#### `add1fun`

The name says it all: `add1fun` is a function that adds 1 to its argument.  Modify the let binding to the correct `expr` value representing this function. Example evaluation: `eval (Apply(add1fun, IntC 16)) []` should evaluate to `IntR 17`

#### `collatz_fun`

The *Collatz Function* takes an integer `n`, and checks if `n` is odd. If it is not, the function returns `n/2`, and otherwise it return `3*n+1`.  We can test whether `n` is odd by checking whether `2*(n/2) = n`.  Modify the let binding to a correct expr value representing this function.  Example evaluation: `eval (Apply(collatz_fun, IntC 31)) []` should evaluate to `IntR 94`.

#### `kdelta`

The *Kronecker delta function* takes two integers as arguments and returns 1 if they are the same, and 0 otherwise.  Modify the let binding to a correct expr value representing this function.  Example evaluation: `eval (Apply(Apply(kdelta, IntC 17), IntC 3)) []` should evaluation to `IntR 0`.

### `inline` and `subst`

We will also write a program transformation, `inline`, and its helper function `subst`.  The program transformation `inline : expr -> expr` finds all of the `Let` and `Apply` subexpressions in its argument, and "inlines" the computation by replacing every instance of the `Name` referring to the argument (of a function) or bound name (of a let) with the subexpression it represents.  This replacement is achieved by calling the `subst : expr -> string -> expr -> expr` function, which replaces every `Name` subexpression with label matching its second argument with the expression given as its first argument.  So:

+ `subst (IntC 1) "x" (Name "x")` should evaluate to `IntC 1`

+ `inline (Let ("x", IntC 1, Name "x"))` should evaluate to `IntC 1`

+ `inline (Apply(Fun("x", IntT, Name "x"), IntC 1))` should also evalute to `IntC 1`.

And furthermore:

+ `inline (Apply(Apply(kdelta, IntC 3), IntC 3))` should evaluate to `If (Eq (IntC 3, IntC 3), IntC 1, IntC 0)`

+ `inline (Apply(collatz_fun,IntC 31))` should evaluate to `If (Eq (Mul (Div (IntC 31, IntC 2), IntC 2), IntC 31), Div (IntC 31, IntC 2), Add (Mul (IntC 3, IntC 31), IntC 1))`.

Fill in the definitions for these functions.

#### _Test cases_

One for each example evaluation given above.

Your solution must pass 4/8 test cases to get full credit for this problem.

# 2.Evaluations in _`lazyCaml`_

Copy the file [`lab9/lazy_eval.md`](lazy_eval.md) into your personal `lab9` directory, where you will record your answers for this question.

Consider the following _`lazyCaml`_ definitions:

```
let rec squares n = (n*n)::(squares (n+1))

let factorials () =
  let rec fac_acc n a = n*a :: (fac_acc (n+1) (n*a)) in
  fac_acc 1 1

let rec fold_right f lst init = match lst with
   | [] -> init
   | (h::t) -> f h (fold_right f t init)

let rec map f lst = match lst with
  | [] -> []
  | (h::t) -> (f h)::(map f t)

let rec sum_list lst = match lst with
  | [] -> 0
  | (h::t) -> h + (sum_list t)
```

Using these definitions, consider the following expressions.  For each
expression, state whether the expression evaluates to a normal form in
a finite number of steps (Normal Form), or the expression will never reach a normal
form (Never) under lazy evaluation.  For those expressions that will reach a
normal form, give the resulting value on the following line.  You should attempt to
explain your reasoning on the following line.

1. `take 2 (squares 3)`

2. `fold_right (&&) (map ((<) 0) (squares 2)) true`

3. `fold_right (||)  (map (fun n -> n mod 3 = 0) (factorials ())) false`

4. `take (sum_list (squares 1)) (factorials ())`

5. `take 1 (reverse (squares 2))`

6. `fold_right (+) (take 1 (factorials ())) 0`

7. `(fun x -> if false then x else ()) (flip 0 0)`

Your solution should match the following format:

```
1. `take 2 (squares 3)`
Normal Form
[9; 16]

```

#### _Test Cases:_

In order to receive full credit for this problem, your solution should have the correct "Normal Form / Never" result and the corresponding Normal Form value for at least 4/7 cases.

# 3. MOAR Lazy Evaluation

Consider the following function definitions, in _`lazyCaml`_ (same
syntax as OCaml, but using lazy evaluation):

```
type 'a tree = Leaf of 'a | EmptyT | Node of 'a tree * 'a tree

let rec crazytree n v = if n = 0 then (Leaf v) else
        Node(crazytree (n-1) ("a"^v), crazytree n ("buffalo"^v))

let rec treefind t v = match t with
| EmptyT -> false
| Leaf v' -> v'=v
| Node(l,r) -> (treefind l v) || (treefind r v)

let rec eqtree t1 t2 = match (t1,t2) with
| (EmptyT,EmptyT) -> true
| (Leaf v1, Leaf v2) -> v1=v2
| (Node (l1,r1), Node (l2,r2)) -> (eqtree r1 r2) && (eqtree l1 l2)
| _ -> false
```

The file `lazytreeval.md` contains four _`lazyCaml`_ expressions using these
definitions.  For each expression, state whether the expression evaluates to a
normal form in a finite number of steps (Normal Form), or the expression will
never reach a normal form (Never) under lazy evaluation.  For those expressions
that will reach a normal form, give the resulting value on the following line.
You should attempt to explain your reasoning on the following line.

#### _Test Cases_  

To get full credit for problem 3 your solution should earn at least 3/4 points.
