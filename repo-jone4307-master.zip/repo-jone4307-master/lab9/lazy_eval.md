1. `take 2 (squares 3)`
Normal Form
[9; 16]

2. `fold_right (&&) (map ((<) 0) (squares 2)) true`
Never
ends with false because the only mapping things less than 0 but squares is always positive

3. `fold_right (||)  (map (fun n -> n mod 3 = 0) (factorials ())) false`
Normal Form
true

4. `take (sum_list (squares 1)) (factorials ())`
Never
the number for take is not determined by the first call to each thing

5. `take 1 (reverse (squares 2))`
Choose Normal Form or Never
Put a value here, and/or an explanation

6. `fold_right (+) (take 1 (factorials ())) 0`
Choose Normal Form or Never
Put a value here, and/or an explanation

7. `(fun x -> if false then x else ()) (flip 0 0)`
Choose Normal Form or Never
Put a value here, and/or an explanation
