## Assessment for Lab 9

Run on March 30, 08:13:27 AM.

+ Pass: Change into directory "lab9".

### Part 1: Expression tree functions and call-by-name

+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   eval (Apply(add1fun, IntC 16)) []
   ```
   matches the pattern `IntR 17`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   eval (Apply(collatz_fun, IntC 31)) []
   ```
   matches the pattern `IntR 94`.

   




+  _1_ / _1_ : Pass: 
Check that the result of evaluating
   ```
   eval (Apply(Apply(kdelta, IntC 17), IntC 3)) []
   ```
   matches the pattern `IntR 0`.

   




+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   subst (IntC 1) "x" (Name "x")
   ```
   matches the pattern `IntC 1`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: This function has type 'a -> expr
       It is applied to too many arguments; maybe you forgot a `;'.

```



+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   inline (Let ("x", IntC 1, Name "x"))
   ```
   matches the pattern `IntC 1`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : expr = Let ("x", IntC 1, Name "x")
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   inline (Apply(Fun("x", IntT, Name "x"), IntC 1))
   ```
   matches the pattern `IntC 1`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : expr = Apply (Fun ("x", IntT, Name "x"), IntC 1)
`


+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   inline (Apply(Apply(kdelta, IntC 3), IntC 3))
   ```
   matches the pattern `If (Eq (IntC 3, IntC 3), IntC 1, IntC 0)`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
- : expr =
Apply
 (Apply
   (Fun ("x", IntT,
     Fun ("y", IntT, If (Eq (Name "x", Name "y"), IntC 1, IntC 0))),
   IntC 3),
 IntC 3)

```



+  _0_ / _1_ : Fail: 
Check that the result of evaluating
   ```
   inline (Apply(collatz_fun,IntC 31))
   ```
   matches the pattern `If (Eq (Mul (Div (IntC 31, IntC 2), IntC 2), IntC 31), Div (IntC 31, IntC 2), Add (Mul (IntC 3, IntC 31), IntC 1))`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
- : expr =
Apply
 (Fun ("x", IntT,
   If (Eq (Name "x", Mul (IntC 2, Div (Name "x", IntC 2))),
    Div (Name "x", IntC 2), Add (IntC 1, Mul (Name "x", IntC 3)))),
 IntC 31)

```



#### Subtotal: _3_ / _8_

### Part 2: Evaluations in _`lazyCaml`_

+  _1_ / _1_ : Pass: Item 1 of list in lazy_eval.md passes Normal Form with correct evaluation result test

+  _1_ / _1_ : Pass: Item 2 of list in lazy_eval.md passes Never with explanation test

+  _1_ / _1_ : Pass: Item 3 of list in lazy_eval.md passes Normal Form with correct evaluation result test

+  _1_ / _1_ : Pass: Item 4 of list in lazy_eval.md passes Never with explanation test

+  _0_ / _1_ : Fail: Item 5 of list in lazy_eval.md 

+  _0_ / _1_ : Fail: Item 6 of list in lazy_eval.md 

+  _0_ / _1_ : Fail: Item 7 of list in lazy_eval.md 

#### Subtotal: _4_ / _7_

### Part 3: MOAR Lazy Evaluation

+  _0_ / _1_ : Fail: Item 1 of list in lazytreeval.md 

+  _1_ / _1_ : Pass: Item 2 of list in lazytreeval.md passes Never with explanation test

+  _1_ / _1_ : Pass: Item 3 of list in lazytreeval.md passes Normal Form with correct evaluation result test

+  _1_ / _1_ : Pass: Item 4 of list in lazytreeval.md passes Never with explanation test

#### Subtotal: _3_ / _4_



Solutions to all exercise sets appear in [github](https://github.umn.edu/csci2041-s22/solutions/)

