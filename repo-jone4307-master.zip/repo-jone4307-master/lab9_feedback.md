### Feedback for Lab 9

Run on March 28, 15:30:53 PM.

+ Pass: Change into directory "lab9".

+ Pass: Check that file "funval.ml" exists.

+ Pass: 
Check that the result of evaluating
   ```
   eval (Apply(add1fun, IntC 16)) []
   ```
   matches the pattern `IntR 17`.

   




+ Pass: 
Check that the result of evaluating
   ```
   eval (Apply(collatz_fun, IntC 31)) []
   ```
   matches the pattern `IntR 94`.

   




+ Pass: 
Check that the result of evaluating
   ```
   eval (Apply(Apply(kdelta, IntC 17), IntC 3)) []
   ```
   matches the pattern `IntR 0`.

   




+ Fail: 
Check that the result of evaluating
   ```
   subst (IntC 1) "x" (Name "x")
   ```
   matches the pattern `IntC 1`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
[0m[1;31mError[0m: This function has type 'a -> expr
       It is applied to too many arguments; maybe you forgot a `;'.

```



+ Fail: 
Check that the result of evaluating
   ```
   inline (Let ("x", IntC 1, Name "x"))
   ```
   matches the pattern `IntC 1`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : expr = Let ("x", IntC 1, Name "x")
`


+ Fail: 
Check that the result of evaluating
   ```
   inline (Apply(Fun("x", IntT, Name "x"), IntC 1))
   ```
   matches the pattern `IntC 1`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 ` ;;
- : expr = Apply (Fun ("x", IntT, Name "x"), IntC 1)
`


+ Fail: 
Check that the result of evaluating
   ```
   inline (Apply(Apply(kdelta, IntC 3), IntC 3))
   ```
   matches the pattern `If (Eq (IntC 3, IntC 3), IntC 1, IntC 0)`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
- : expr =
Apply
 (Apply
   (Fun ("x", IntT,
     Fun ("y", IntT, If (Eq (Name "x", Name "y"), IntC 1, IntC 0))),
   IntC 3),
 IntC 3)

```



+ Fail: 
Check that the result of evaluating
   ```
   inline (Apply(collatz_fun,IntC 31))
   ```
   matches the pattern `If (Eq (Mul (Div (IntC 31, IntC 2), IntC 2), IntC 31), Div (IntC 31, IntC 2), Add (Mul (IntC 3, IntC 31), IntC 1))`.

   


   Your solution evaluated incorrectly and produced some part of the following:

 
```
 ;;
- : expr =
Apply
 (Fun ("x", IntT,
   If (Eq (Name "x", Mul (IntC 2, Div (Name "x", IntC 2))),
    Div (Name "x", IntC 2), Add (IntC 1, Mul (Name "x", IntC 3)))),
 IntC 31)

```



+ Pass: Check that file "lazy_eval.md" exists.

+ Pass: Item 1 of list in lazy_eval.md passes Normal Form with correct evaluation result test

+ Pass: Item 2 of list in lazy_eval.md passes Never with explanation test

+ Pass: Item 3 of list in lazy_eval.md passes Normal Form with correct evaluation result test

+ Pass: Item 4 of list in lazy_eval.md passes Never with explanation test

+ Fail: Item 5 of list in lazy_eval.md 

+ Fail: Item 6 of list in lazy_eval.md 

+ Fail: Item 7 of list in lazy_eval.md 

+ Pass: Check that file "lazytreeval.md" exists.

+ Fail: Item 1 of list in lazytreeval.md 

+ Pass: Item 2 of list in lazytreeval.md passes Never with explanation test

+ Pass: Item 3 of list in lazytreeval.md passes Normal Form with correct evaluation result test

+ Pass: Item 4 of list in lazytreeval.md passes Never with explanation test

